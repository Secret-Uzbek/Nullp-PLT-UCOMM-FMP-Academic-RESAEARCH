TCPP v1.0 Release Automation Package
====================================

Files included:
- release_tcpp_v1.0.sh  : script to create draft releases and upload ZIP (needs env vars GITHUB_TOKEN, OWNER, ZIPFILE)
- TCPP_v1.0_release.zip : primary release artifact (already included)
- terra_ledger_update_template.json : template to update Terra Proof Ledger after DOI appears
- release_report.json : summary report with SHA256 checksums

Quick steps:
1) Place this package on a machine with curl and jq.
2) Export environment variables:
   export GITHUB_TOKEN="your_pat_here"
   export OWNER="Secret-Uzbek"
   export ZIPFILE="$(pwd)/TCPP_v1.0_release.zip"
3) Run: ./release_tcpp_v1.0.sh
4) Go to GitHub releases pages and publish draft releases manually.
5) After Zenodo assigns DOI, update terra_ledger_update_template.json with the DOI and SHA256, then push to your ledger repo.

Operator mode: no further prompts — script handles creation of drafts and uploads.

