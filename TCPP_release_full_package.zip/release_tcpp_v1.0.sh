#!/usr/bin/env bash
# release_tcpp_v1.0.sh
#  - Creates draft releases and uploads TCPP_v1.0_release.zip to target repos
#  - Usage: ./release_tcpp_v1.0.sh
#  - Requires: curl, jq
#  - Environment variables required:
#       GITHUB_TOKEN  (your PAT)
#       OWNER (e.g., Secret-Uzbek)
#       ZIPFILE (path to TCPP_v1.0_release.zip)
set -euo pipefail
if [ -z "${GITHUB_TOKEN:-}" ]; then
  echo "ERROR: GITHUB_TOKEN not set"; exit 2
fi
if [ -z "${OWNER:-}" ]; then
  echo "ERROR: OWNER not set"; exit 2
fi
if [ -z "${ZIPFILE:-}" ]; then
  echo "ERROR: ZIPFILE not set"; exit 2
fi
REPOS=( "AIUZ-Terra-Ecosystem" "Theory-of-fractal-metascience-paradigm" )
TAG="v1.0-tcpp"
NAME="Terra Challenge Proof Protocol v1.0"
BODY="Initial TCPP v1.0 release package (Fractal Metascience Paradigm core + ecosystem layer)."

for REPO in "${REPOS[@]}"; do
  echo "===> Creating draft release for ${OWNER}/${REPO}"
  RESP=$(curl -s -X POST     -H "Authorization: Bearer ${GITHUB_TOKEN}"     -H "Accept: application/vnd.github+json"     "https://api.github.com/repos/${OWNER}/${REPO}/releases"     -d "{"tag_name":"${TAG}","name":"${NAME}","body":"${BODY}","draft":true}" )
  echo "$RESP" | jq -r '.message // empty' >/dev/null || true
  UPLOAD_URL=$(echo "$RESP" | jq -r '.upload_url' | sed 's/{?name,label}//')
  if [ -z "$UPLOAD_URL" ] || [ "$UPLOAD_URL" = "null" ]; then
    echo "Failed to create release for ${REPO}: $RESP"
    continue
  fi
  echo "Uploading ${ZIPFILE} to ${REPO} ..."
  curl -s -X POST     -H "Authorization: Bearer ${GITHUB_TOKEN}"     -H "Accept: application/vnd.github+json"     -H "Content-Type: application/zip"     --data-binary @"${ZIPFILE}"     "${UPLOAD_URL}?name=$(basename "${ZIPFILE}")&label=$(basename "${ZIPFILE}")"     | jq -r '.browser_download_url // .name // .' || true
  echo "Draft release created for ${OWNER}/${REPO}. Check https://github.com/${OWNER}/${REPO}/releases"
done
echo "All done. Publish drafts manually or via API by setting "draft":false."
