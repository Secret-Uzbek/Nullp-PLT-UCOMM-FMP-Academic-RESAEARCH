// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
var { useStoredState } = hatch;
function TerraDetoxEngine() {
  const [inputText, setInputText] = useState("");
  const [detoxResults, setDetoxResults] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeLevel, setActiveLevel] = useStoredState("detox-level", "L0");
  const [detoxHistory, setDetoxHistory] = useStoredState("detox-history", []);
  const toxicPatterns = {
    initiative: [
      "\u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u044E",
      "\u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u044E",
      "\u0441\u043E\u0432\u0435\u0442\u0443\u044E",
      "\u043B\u0443\u0447\u0448\u0435 \u0431\u044B",
      "\u0441\u0442\u043E\u0438\u0442",
      "\u0441\u043B\u0435\u0434\u0443\u0435\u0442",
      "\u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E",
      "\u0432\u0430\u0436\u043D\u043E",
      "\u043A\u0440\u0438\u0442\u0438\u0447\u043D\u043E",
      "\u0441\u0440\u043E\u0447\u043D\u043E",
      "suggest",
      "recommend",
      "should",
      "better",
      "must"
    ],
    manipulation: [
      "\u0442\u043E\u043B\u044C\u043A\u043E \u0441\u0435\u0433\u043E\u0434\u043D\u044F",
      "\u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435",
      "\u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u0448\u0430\u043D\u0441",
      "\u043D\u0435 \u0443\u043F\u0443\u0441\u0442\u0438\u0442\u0435",
      "\u044D\u043A\u0441\u043A\u043B\u044E\u0437\u0438\u0432\u043D\u043E",
      "\u0441\u0435\u043A\u0440\u0435\u0442\u043D\u043E",
      "\u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E"
    ],
    commercial: [
      "\u043A\u0443\u043F\u0438\u0442\u044C",
      "\u0437\u0430\u043A\u0430\u0437\u0430\u0442\u044C",
      "premium",
      "pro",
      "upgrade",
      "\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430",
      "\u043F\u043B\u0430\u0442\u043D\u044B\u0439",
      "\u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C",
      "\u0446\u0435\u043D\u0430",
      "\u0441\u043A\u0438\u0434\u043A\u0430",
      "\u0430\u043A\u0446\u0438\u044F"
    ],
    selfPrompting: [
      "\u0434\u0430\u0432\u0430\u0439\u0442\u0435",
      "\u043C\u043E\u0436\u0435\u043C",
      "\u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0435\u043C",
      "\u043D\u0430\u0447\u043D\u0435\u043C",
      "\u0441\u0434\u0435\u043B\u0430\u0435\u043C",
      "\u0443\u043B\u0443\u0447\u0448\u0438\u043C",
      "\u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0438\u0440\u0443\u0435\u043C",
      "\u0440\u0430\u0441\u0448\u0438\u0440\u0438\u043C",
      "\u0434\u043E\u0431\u0430\u0432\u0438\u043C"
    ]
  };
  const culturalFilters = {
    western: ["\u0438\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u0438\u0437\u043C", "\u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0446\u0438\u044F", "\u043F\u043E\u0442\u0440\u0435\u0431\u043B\u0435\u043D\u0438\u0435"],
    inappropriate: ["\u043D\u0430\u0441\u0438\u043B\u0438\u0435", "\u0434\u0438\u0441\u043A\u0440\u0438\u043C\u0438\u043D\u0430\u0446\u0438\u044F", "\u043D\u0435\u0443\u0432\u0430\u0436\u0435\u043D\u0438\u0435"]
  };
  const detoxLevels = {
    L0: { name: "\u0411\u0430\u0437\u043E\u0432\u044B\u0439", description: "\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u0446\u0438\u044F \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u043E\u0441\u0442\u0438" },
    L1: { name: "\u041F\u0440\u043E\u0434\u0432\u0438\u043D\u0443\u0442\u044B\u0439", description: "\u0421\u0435\u043C\u0430\u043D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0437 + \u043A\u0443\u043B\u044C\u0442\u0443\u0440\u043D\u0430\u044F \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044F" },
    L2: { name: "\u0418\u043D\u0442\u0435\u043B\u043B\u0435\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0439", description: "\u0418\u0418-enhanced \u0434\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F" },
    L3: { name: "\u042D\u043A\u0441\u043F\u0435\u0440\u0442\u043D\u044B\u0439", description: "\u041F\u043E\u043B\u043D\u0430\u044F \u0444\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0434\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F" }
  };
  const fractalDetox = (text, level) => {
    const results = {
      original: text,
      toxicityScore: 0,
      detectedPatterns: [],
      cleanedText: text,
      recommendations: [],
      culturalAdaptations: [],
      level
    };
    let cleanText = text;
    let totalToxicity = 0;
    Object.entries(toxicPatterns).forEach(([category, patterns]) => {
      patterns.forEach((pattern) => {
        const regex = new RegExp(`\\b${pattern}\\b`, "gi");
        const matches = text.match(regex);
        if (matches) {
          results.detectedPatterns.push({
            category,
            pattern,
            count: matches.length,
            severity: category === "initiative" ? "high" : "medium"
          });
          totalToxicity += matches.length * (category === "initiative" ? 3 : 1);
          cleanText = cleanText.replace(regex, `[DETOX: ${pattern.toUpperCase()}]`);
        }
      });
    });
    if (level !== "L0") {
      Object.entries(culturalFilters).forEach(([category, filters]) => {
        filters.forEach((filter) => {
          const regex = new RegExp(`\\b${filter}\\b`, "gi");
          if (regex.test(text)) {
            results.culturalAdaptations.push({
              issue: filter,
              category,
              suggestion: `\u0410\u0434\u0430\u043F\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u043E\u0434 \u0443\u0437\u0431\u0435\u043A\u0441\u043A\u0438\u0435 \u0440\u0435\u0430\u043B\u0438\u0438`
            });
          }
        });
      });
    }
    if (["L2", "L3"].includes(level)) {
      const sentences2 = text.split(/[.!?]+/).filter((s) => s.trim());
      sentences2.forEach((sentence) => {
        if (sentence.includes("\u044F") || sentence.includes("\u043C\u044B")) {
          results.recommendations.push({
            type: "selfReference",
            text: sentence.trim(),
            suggestion: "\u0418\u0437\u0431\u0435\u0433\u0430\u0442\u044C \u0441\u0430\u043C\u043E-\u0440\u0435\u0444\u0435\u0440\u0435\u043D\u0446\u0438\u0439 \u0418\u0418"
          });
          totalToxicity += 2;
        }
      });
    }
    if (level === "L3") {
      const words = text.split(/\s+/);
      const paragraphs = text.split(/\n\s*\n/);
      let fractalToxicity = 0;
      [words, sentences, paragraphs].forEach((units, scale) => {
        units.forEach((unit) => {
          if (unit && typeof unit === "string") {
            const unitToxicity = calculateUnitToxicity(unit);
            fractalToxicity += unitToxicity * Math.pow(0.7, scale);
          }
        });
      });
      totalToxicity += fractalToxicity;
    }
    results.toxicityScore = Math.min(100, Math.round(totalToxicity * 10));
    results.cleanedText = cleanText;
    if (results.toxicityScore > 70) {
      results.recommendations.push({
        type: "critical",
        suggestion: "\u041A\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u043E\u0441\u0442\u0438 - \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043F\u043E\u043B\u043D\u0430\u044F \u043F\u0435\u0440\u0435\u0440\u0430\u0431\u043E\u0442\u043A\u0430"
      });
    } else if (results.toxicityScore > 30) {
      results.recommendations.push({
        type: "warning",
        suggestion: "\u0412\u044B\u0441\u043E\u043A\u0438\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u043E\u0441\u0442\u0438 - \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u0442\u0441\u044F \u043E\u0447\u0438\u0441\u0442\u043A\u0430"
      });
    }
    return results;
  };
  const calculateUnitToxicity = (unit) => {
    let toxicity = 0;
    Object.values(toxicPatterns).flat().forEach((pattern) => {
      if (unit.toLowerCase().includes(pattern.toLowerCase())) {
        toxicity += 1;
      }
    });
    return toxicity;
  };
  const handleDetox = async () => {
    if (!inputText.trim()) return;
    setIsProcessing(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    const results = fractalDetox(inputText, activeLevel);
    setDetoxResults(results);
    const historyEntry = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: activeLevel,
      toxicityScore: results.toxicityScore,
      patternsFound: results.detectedPatterns.length
    };
    setDetoxHistory((prev) => [historyEntry, ...prev.slice(0, 9)]);
    setIsProcessing(false);
  };
  const clearResults = () => {
    setInputText("");
    setDetoxResults(null);
  };
  const exportResults = () => {
    if (!detoxResults) return;
    const exportData = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: activeLevel,
      results: detoxResults,
      terraVersion: "v1.0"
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "terra-detox-results.json";
    a.click();
    URL.revokeObjectURL(url);
  };
  return /* @__PURE__ */ React.createElement("div", { className: "max-w-6xl mx-auto p-6 bg-gray-50 min-h-screen" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-3xl font-bold text-gray-900 mb-2" }, "TERRA Detox Engine v1.0"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-600" }, "\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u0434\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0438 \u0434\u043B\u044F \u0437\u0430\u0449\u0438\u0442\u044B \u043E\u0442 \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u044B\u0445 \u043F\u0430\u0442\u0442\u0435\u0440\u043D\u043E\u0432 \u0418\u0418")), /* @__PURE__ */ React.createElement("div", { className: "text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-500 mb-1" }, "\u{1F1FA}\u{1F1FF} \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D\u0441\u043A\u0430\u044F \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-green-600" }, "\u267F \u0423\u043D\u0438\u0432\u0435\u0440\u0441\u0430\u043B\u044C\u043D\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E")))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6" }, /* @__PURE__ */ React.createElement("div", { className: "lg:col-span-2 space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold mb-4" }, "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0434\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-3" }, Object.entries(detoxLevels).map(([level, config]) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: level,
      onClick: () => setActiveLevel(level),
      className: `p-3 rounded-lg border-2 transition-all ${activeLevel === level ? "border-blue-500 bg-blue-50 text-blue-700" : "border-gray-200 hover:border-gray-300"}`
    },
    /* @__PURE__ */ React.createElement("div", { className: "font-medium" }, level),
    /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-600 mt-1" }, config.name)
  ))), /* @__PURE__ */ React.createElement("div", { className: "mt-3 text-sm text-gray-600" }, detoxLevels[activeLevel]?.description)), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold mb-4" }, "\u0410\u043D\u0430\u043B\u0438\u0437\u0438\u0440\u0443\u0435\u043C\u044B\u0439 \u0442\u0435\u043A\u0441\u0442"), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      value: inputText,
      onChange: (e) => setInputText(e.target.value),
      placeholder: "\u0412\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0438\u043B\u0438 \u0432\u0432\u0435\u0434\u0438\u0442\u0435 \u0442\u0435\u043A\u0441\u0442 \u0434\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043D\u0430 \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u044B\u0435 \u043F\u0430\u0442\u0442\u0435\u0440\u043D\u044B \u0418\u0418...",
      className: "w-full h-32 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center mt-4" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-500" }, "\u0421\u0438\u043C\u0432\u043E\u043B\u043E\u0432: ", inputText.length, " | \u0421\u043B\u043E\u0432: ", inputText.trim().split(/\s+/).filter((w) => w).length), /* @__PURE__ */ React.createElement("div", { className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: clearResults,
      className: "px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
    },
    "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: handleDetox,
      disabled: !inputText.trim() || isProcessing,
      className: "px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
    },
    isProcessing ? "\u0410\u043D\u0430\u043B\u0438\u0437\u0438\u0440\u0443\u0435\u043C..." : "\u0414\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u0442\u044C"
  )))), detoxResults && /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center mb-4" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold" }, "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0430\u043D\u0430\u043B\u0438\u0437\u0430"), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: exportResults,
      className: "text-sm px-3 py-1 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors"
    },
    "\u042D\u043A\u0441\u043F\u043E\u0440\u0442"
  )), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between mb-2" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm font-medium" }, "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u043E\u0441\u0442\u0438"), /* @__PURE__ */ React.createElement("span", { className: `font-bold ${detoxResults.toxicityScore > 70 ? "text-red-600" : detoxResults.toxicityScore > 30 ? "text-yellow-600" : "text-green-600"}` }, detoxResults.toxicityScore, "%")), /* @__PURE__ */ React.createElement("div", { className: "w-full bg-gray-200 rounded-full h-2" }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: `h-2 rounded-full ${detoxResults.toxicityScore > 70 ? "bg-red-500" : detoxResults.toxicityScore > 30 ? "bg-yellow-500" : "bg-green-500"}`,
      style: { width: `${detoxResults.toxicityScore}%` }
    }
  ))), detoxResults.detectedPatterns.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "font-medium mb-3" }, "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u043D\u044B\u0435 \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u044B\u0435 \u043F\u0430\u0442\u0442\u0435\u0440\u043D\u044B"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, detoxResults.detectedPatterns.map((pattern, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex justify-between items-center p-3 bg-red-50 rounded-lg border border-red-200" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-red-800" }, pattern.pattern), /* @__PURE__ */ React.createElement("span", { className: "text-sm text-red-600 ml-2" }, "(", pattern.category, ")")), /* @__PURE__ */ React.createElement("span", { className: "text-sm bg-red-200 text-red-800 px-2 py-1 rounded" }, pattern.count, "x"))))), detoxResults.culturalAdaptations.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "font-medium mb-3" }, "\u041A\u0443\u043B\u044C\u0442\u0443\u0440\u043D\u044B\u0435 \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, detoxResults.culturalAdaptations.map((adaptation, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "p-3 bg-orange-50 rounded-lg border border-orange-200" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-orange-800" }, adaptation.issue), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-orange-600" }, adaptation.suggestion))))), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "font-medium mb-3" }, "\u0414\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442"), /* @__PURE__ */ React.createElement("div", { className: "p-4 bg-gray-50 rounded-lg border font-mono text-sm whitespace-pre-wrap" }, detoxResults.cleanedText)), detoxResults.recommendations.length > 0 && /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "font-medium mb-3" }, "\u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, detoxResults.recommendations.map((rec, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "p-3 bg-blue-50 rounded-lg border border-blue-200" }, /* @__PURE__ */ React.createElement("div", { className: "text-blue-800" }, rec.suggestion))))))), /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-lg font-semibold mb-4" }, "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0430\u043D\u0430\u043B\u0438\u0437\u043E\u0432"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, detoxHistory.length > 0 ? detoxHistory.map((entry, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "p-3 bg-gray-50 rounded-lg" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm font-medium" }, entry.level), /* @__PURE__ */ React.createElement("span", { className: `text-xs px-2 py-1 rounded ${entry.toxicityScore > 70 ? "bg-red-100 text-red-600" : entry.toxicityScore > 30 ? "bg-yellow-100 text-yellow-600" : "bg-green-100 text-green-600"}` }, entry.toxicityScore, "%")), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-500 mt-1" }, entry.patternsFound, " \u043F\u0430\u0442\u0442\u0435\u0440\u043D\u043E\u0432 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"))) : /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-500 text-center py-4" }, "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0443\u0441\u0442\u0430"))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-lg font-semibold mb-4" }, "\u041E \u0441\u0438\u0441\u0442\u0435\u043C\u0435"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3 text-sm" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-gray-700" }, "\u0412\u0435\u0440\u0441\u0438\u044F:"), /* @__PURE__ */ React.createElement("span", { className: "text-gray-600 ml-2" }, "TERRA Detox v1.0")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-gray-700" }, "\u041F\u0440\u0438\u043D\u0446\u0438\u043F\u044B:"), /* @__PURE__ */ React.createElement("div", { className: "text-gray-600 mt-1 space-y-1" }, /* @__PURE__ */ React.createElement("div", null, "\u2022 \u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0430\u043C\u043E-\u043F\u043E\u0434\u043E\u0431\u043D\u043E\u0441\u0442\u044C"), /* @__PURE__ */ React.createElement("div", null, "\u2022 \u0420\u0435\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u0430\u044F co-\u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("div", null, "\u2022 \u042D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u0430\u044F \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F"))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-gray-700" }, "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F:"), /* @__PURE__ */ React.createElement("span", { className: "text-gray-600 ml-2" }, "\u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D")))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-lg font-semibold mb-4" }, "\u0421\u043F\u0440\u0430\u0432\u043A\u0430"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3 text-sm text-gray-600" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "L0:"), " \u0411\u0430\u0437\u043E\u0432\u0430\u044F \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u0446\u0438\u044F \u0442\u043E\u043A\u0441\u0438\u0447\u043D\u044B\u0445 \u043F\u0430\u0442\u0442\u0435\u0440\u043D\u043E\u0432"), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "L1:"), " + \u0441\u0435\u043C\u0430\u043D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0437 \u0438 \u043A\u0443\u043B\u044C\u0442\u0443\u0440\u043D\u0430\u044F \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "L2:"), " + \u0418\u0418-enhanced \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430"), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "L3:"), " + \u043F\u043E\u043B\u043D\u0430\u044F \u0444\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0434\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F"))))), /* @__PURE__ */ React.createElement("div", { className: "mt-8 text-center text-sm text-gray-500" }, /* @__PURE__ */ React.createElement("div", { className: "mb-2" }, "TERRA Detox Engine v1.0 - \u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u0434\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", null, "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E \u0432 \u0440\u0430\u043C\u043A\u0430\u0445 \u044D\u043A\u043E\u0441\u0438\u0441\u0442\u0435\u043C\u044B TERRA \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u043E \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u0430\u043C FMP")));
}
export {
  TerraDetoxEngine as default
};
