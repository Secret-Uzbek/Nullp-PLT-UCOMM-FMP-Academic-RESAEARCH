Dear Editor,

Please find attached the Terra Challenge Proof Protocol v1.0 release package, which documents the TCPP reproducible pipeline. The package includes templates and reproducible artifacts necessary for verification and archival. We request consideration for publication/archival as appropriate.

Sincerely,
Abdurashid Abdukarimov
