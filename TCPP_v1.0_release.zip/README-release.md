# TCPP v1.0 Release Package

Prepared by: Abdurashid Abdukarimov (ORCID: 0009-0000-6394-4912)
Date: 2025-10-21

This package contains the Terra Challenge Proof Protocol v1.0 release artifacts:

Files included:
- ingestion.json (problem ingestion template)
- FPG_example.jsonld (Fractal Problem Graph example)
- article-draft.tex (LaTeX IMRaD skeleton)
- Dockerfile (reproducibility starter)
- environment.lock (environment snapshot placeholder)
- .zenodo.json (metadata template for Zenodo upload)
- terra_proof_ledger_TERRA-PROOF-2025-001.json (ledger entry template)
- press_release.md (one-page press brief)
- cover_letter.md (journal cover letter template)
- checksums.sha256 (SHA256 checksums for verification)

Instructions:
1. Create a GitHub release (tag: v1.0-tcpp) and upload the zip archive 'TCPP_v1.0_release.zip'.
2. If GitHub ↔ Zenodo integration is enabled, Zenodo will create a deposit and mint a DOI automatically when the release is published.
3. After DOI appears, update Terra Proof Ledger with the issued DOI and checksum.

Notes:
- This package is ready for manual review and adjustment before publication.
