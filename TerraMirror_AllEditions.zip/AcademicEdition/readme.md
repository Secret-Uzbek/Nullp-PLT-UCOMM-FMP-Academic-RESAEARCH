# Academic Edition
Contains publication artifacts.