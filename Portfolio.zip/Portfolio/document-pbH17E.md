# ОФИЦИАЛЬНОЕ ПИСЬМО ПОДДЕРЖКИ

## Кандидатура Йоахима Лёва на пост главного тренера сборной Узбекистана

***

**Кому:**

* **Ирматов Равшан Сайфиддинович** - Первый Вице-Президент УФА
* **Ахмедов Одил Алимджанович** - Вице-Президент УФА
* **Максумов Аваз Пархатович** - Генеральный секретарь УФА

**Адрес:** Узбекская Футбольная Ассоциация\
100011, Ташкент, ул. Ислама Каримова, 98/А

**Контакты УФА:**

* 📞 +99871 230 90 42, +99871 230 90 45
* 📠 +99871 230 90 51
* 📧 <uzb@the-afc.com>, <info@ufa.uz>, <UFA@ehat.uz>

***

## 🇺🇿 O'ZBEK TILIDA

**Hurmatli Uzbekiston Futbol Assotsiatsiyasi rahbariyati!**

**Ирматов Равшан Сайфиддинович**га - Birinchi Vitse-Prezident\
**Ахмедов Одил Алимджанович**га - Vitse-Prezident\
**Максумов Аваз Пархатович**га - Bosh kotib

Men, Abdurashid Abdukarimov, 25 yillik professional tarjimon va biznes konsultant sifatida, **Joachim Löw**ning O'zbekiston milliy futbol terma jamoasi bosh murabbiyligi lavozimiga taklif qilinishi masalasida o'z qo'llab-quvvatlashimni bildirmoqchiman.

### Nima uchun aynan Joachim Löw?

🏆 **2014-yil Jahon chempioni** - futbolda eng yuqori mukofot\
⭐ **FIFA yilning eng yaxshi murabbiyi** - xalqaro tan olingan mahorat\
🎯 **Germaniya terma jamoasi bilan 15 yil** - noyob milliy jamoa tajribasi\
🔥 **Zamonaviy taktika** - hozirgi futbol tendentsiyalariga moslashish\
👨‍🎓 **Iste'dodlarni tarbiyalash** - o'yinchilar salohiyatini ochish mahorati

### O'zbek futboli
