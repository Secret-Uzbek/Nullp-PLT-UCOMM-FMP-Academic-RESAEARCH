#!/usr/bin/env python3
import os, json
# Скрипт формирует архив заявки + метаданные под выбранный фонд
print("Grant bundling script — допиши шаблоны фондов")