// <stdin>
import React, { useState, useEffect, useRef } from "https://esm.sh/react@18.2.0";
var TerraUltimateEcosystem = () => {
  const [selectedLanguage, setSelectedLanguage] = useState("ru");
  const [selectedAge, setSelectedAge] = useState("adult");
  const [selectedPurpose, setSelectedPurpose] = useState(null);
  const [currentModule, setCurrentModule] = useState("portal");
  const [loading, setLoading] = useState(false);
  const [quantumStatus, setQuantumStatus] = useState("STANDBY");
  const [translatorInput, setTranslatorInput] = useState("");
  const [translatorOutput, setTranslatorOutput] = useState("");
  const [aiDictionaryQuery, setAiDictionaryQuery] = useState("");
  const [archPlanParams, setArchPlanParams] = useState({
    area: 1e3,
    type: "residential",
    climate: "tashkent",
    budget: 5e4
  });
  const terraMemoryDNA = {
    version: "7.0",
    quantum_superposition: true,
    codes_integrated: 5,
    fractal_metascience: true,
    creator: "\u0410\u0431\u0434\u0443\u0440\u0430\u0448\u0438\u0434 \u0410\u0431\u0434\u0443\u043A\u0430\u0440\u0438\u043C\u043E\u0432",
    did: "aiuz:did:aiuz:stakeholder:abdukarimov_aaahash1234567890"
  };
  useEffect(() => {
    const interval = setInterval(() => {
      const timestamp = (/* @__PURE__ */ new Date()).toLocaleTimeString();
      setQuantumStatus(`ACTIVE | ${timestamp} | Quantum Coherence: 97.3%`);
    }, 3e3);
    return () => clearInterval(interval);
  }, []);
  const languages = {
    ru: {
      title: "TERRA Ultimate Ecosystem v7.0",
      subtitle: "\u0423\u043D\u0438\u0432\u0435\u0440\u0441\u0430\u043B\u044C\u043D\u0430\u044F \u044D\u043A\u043E\u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u0437\u043D\u0430\u043D\u0438\u0439 \u0441 \u0418\u0418-\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u043E\u0439",
      selectLang: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u044F\u0437\u044B\u043A",
      selectAge: "\u0412\u043E\u0437\u0440\u0430\u0441\u0442",
      selectPurpose: "\u0426\u0435\u043B\u044C",
      enter: "\u0412\u041E\u0419\u0422\u0418",
      modules: {
        translator: "\u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A-\u041F\u0430\u0440\u0441\u0435\u0440",
        aiDict: "AI-\u0421\u043B\u043E\u0432\u0430\u0440\u0438 UZ-DE",
        archPlan: "\u0410\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u043D\u044B\u0439 \u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0449\u0438\u043A",
        learning: "\u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043C\u043E\u0434\u0443\u043B\u044C",
        research: "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F",
        logistics: "\u041B\u043E\u0433\u0438\u0441\u0442\u0438\u043A\u0430 UZ-DE",
        tourism: "\u0422\u0443\u0440\u0438\u0437\u043C UZ-DE"
      }
    },
    en: {
      title: "TERRA Ultimate Ecosystem v7.0",
      subtitle: "Universal knowledge ecosystem with AI support",
      selectLang: "Choose language",
      selectAge: "Age",
      selectPurpose: "Purpose",
      enter: "ENTER",
      modules: {
        translator: "Translator-Parser",
        aiDict: "AI-Dictionaries UZ-DE",
        archPlan: "Architectural Planner",
        learning: "Learning Module",
        research: "Research",
        logistics: "Logistics UZ-DE",
        tourism: "Tourism UZ-DE"
      }
    },
    de: {
      title: "TERRA Ultimate Ecosystem v7.0",
      subtitle: "Universelles Wissens\xF6kosystem mit KI-Unterst\xFCtzung",
      selectLang: "Sprache w\xE4hlen",
      selectAge: "Alter",
      selectPurpose: "Zweck",
      enter: "EINTRETEN",
      modules: {
        translator: "\xDCbersetzer-Parser",
        aiDict: "KI-W\xF6rterb\xFCcher UZ-DE",
        archPlan: "Architektur-Planer",
        learning: "Lernmodul",
        research: "Forschung",
        logistics: "Logistik UZ-DE",
        tourism: "Tourismus UZ-DE"
      }
    },
    uz: {
      title: "TERRA Ultimate Ecosystem v7.0",
      subtitle: "AI qo'llab-quvvatlaydigan universal bilim ekotizimi",
      selectLang: "Tilni tanlang",
      selectAge: "Yosh",
      selectPurpose: "Maqsad",
      enter: "KIRISH",
      modules: {
        translator: "Tarjimon-Parser",
        aiDict: "AI-Lug'atlar UZ-DE",
        archPlan: "Arxitektura rejachi",
        learning: "Ta'lim moduli",
        research: "Tadqiqot",
        logistics: "Logistika UZ-DE",
        tourism: "Turizm UZ-DE"
      }
    }
  };
  const t = languages[selectedLanguage] || languages.ru;
  const handleTranslate = () => {
    const translations = {
      ru: {
        "\u0434\u043E\u043C": "uy (uz) | Haus (de) | house (en)",
        "\u0434\u0435\u0440\u0435\u0432\u043E": "daraxt (uz) | Baum (de) | tree (en)",
        "\u0430\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u0430": "me'morchilik (uz) | Architektur (de) | architecture (en)"
      },
      en: {
        "house": "uy (uz) | Haus (de) | \u0434\u043E\u043C (ru)",
        "tree": "daraxt (uz) | Baum (de) | \u0434\u0435\u0440\u0435\u0432\u043E (ru)",
        "architecture": "me'morchilik (uz) | Architektur (de) | \u0430\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u0430 (ru)"
      }
    };
    const result = translations[selectedLanguage]?.[translatorInput.toLowerCase()] || `\u041F\u0435\u0440\u0435\u0432\u043E\u0434 \u0434\u043B\u044F "${translatorInput}" \u043E\u0431\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u0435\u0442\u0441\u044F \u0447\u0435\u0440\u0435\u0437 Terra AI...`;
    setTranslatorOutput(result);
  };
  const handleAIDictionary = () => {
    const uzDeDict = {
      "kitob": "Buch (de) - \u043A\u043D\u0438\u0433\u0430 (ru) - book (en)",
      "uy": "Haus (de) - \u0434\u043E\u043C (ru) - house (en)",
      "bozor": "Markt (de) - \u0440\u044B\u043D\u043E\u043A (ru) - market (en)"
    };
    const result = uzDeDict[aiDictionaryQuery.toLowerCase()] || `\u0421\u0435\u043C\u0430\u043D\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0441\u0435\u0442\u044C \u0434\u043B\u044F "${aiDictionaryQuery}" \u0441\u0442\u0440\u043E\u0438\u0442\u0441\u044F \u0447\u0435\u0440\u0435\u0437 AI...`;
    setTranslatorOutput(result);
  };
  const calculateArchProject = () => {
    const { area, type, climate, budget } = archPlanParams;
    const climateData = {
      tashkent: { temp: "40\xB0C", humidity: "30%", energy: "\u0432\u044B\u0441\u043E\u043A\u043E\u0435" },
      samarkand: { temp: "42\xB0C", humidity: "25%", energy: "\u043E\u0447\u0435\u043D\u044C \u0432\u044B\u0441\u043E\u043A\u043E\u0435" },
      bukhara: { temp: "45\xB0C", humidity: "20%", energy: "\u044D\u043A\u0441\u0442\u0440\u0435\u043C\u0430\u043B\u044C\u043D\u043E\u0435" }
    };
    const climate_info = climateData[climate] || climateData.tashkent;
    return {
      estimatedCost: budget * 1.2,
      energyConsumption: area * 120,
      // kWh/year
      materials: type === "residential" ? "\u042D\u043A\u043E-\u0431\u0435\u0442\u043E\u043D, \u043C\u0435\u0441\u0442\u043D\u044B\u0439 \u043A\u0430\u043C\u0435\u043D\u044C" : "\u0421\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438",
      timeline: Math.ceil(area / 100) + " \u043C\u0435\u0441\u044F\u0446\u0435\u0432",
      climate: climate_info,
      recommendations: [
        "\u041E\u0442\u0440\u0430\u0436\u0430\u044E\u0449\u0438\u0435 \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u044F \u0434\u043B\u044F \u0436\u0430\u0440\u043A\u043E\u0433\u043E \u043A\u043B\u0438\u043C\u0430\u0442\u0430",
        "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0441\u0431\u043E\u0440\u0430 \u0434\u043E\u0436\u0434\u0435\u0432\u043E\u0439 \u0432\u043E\u0434\u044B",
        "\u041F\u0430\u0441\u0441\u0438\u0432\u043D\u043E\u0435 \u043E\u0445\u043B\u0430\u0436\u0434\u0435\u043D\u0438\u0435"
      ]
    };
  };
  const renderPortal = () => /* @__PURE__ */ React.createElement("div", { className: "min-h-screen bg-gradient-to-br from-green-600 via-blue-600 to-purple-600 flex items-center justify-center p-4" }, /* @__PURE__ */ React.createElement("div", { className: "fixed top-4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-80 text-green-400 px-4 py-2 rounded-full text-sm font-mono animate-pulse z-50" }, "\u269B\uFE0F TERRA v7.0 Quantum: ", quantumStatus), selectedAge === "child" && /* @__PURE__ */ React.createElement("div", { className: "fixed bottom-4 right-4 bg-green-100 border-2 border-green-300 rounded-lg p-3 text-green-800 text-sm animate-pulse" }, "\u{1F6E1}\uFE0F Child Safety Mode: ACTIVE", /* @__PURE__ */ React.createElement("br", null), "\u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C \u0434\u043B\u044F \u0434\u0435\u0442\u0435\u0439"), /* @__PURE__ */ React.createElement("div", { className: "bg-white bg-opacity-95 rounded-3xl shadow-2xl p-8 max-w-4xl w-full" }, /* @__PURE__ */ React.createElement("div", { className: "text-center mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "text-6xl mb-4 animate-pulse" }, "\u{1F30D}"), /* @__PURE__ */ React.createElement("h1", { className: "text-4xl font-bold text-green-700 mb-2" }, t.title), /* @__PURE__ */ React.createElement("p", { className: "text-xl text-gray-600 mb-2" }, t.subtitle), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-purple-600" }, /* @__PURE__ */ React.createElement("em", null, "\u041E\u0431\u044A\u0435\u0434\u0438\u043D\u044F\u044E\u0449\u0430\u044F \u0432\u0441\u0435 \u043A\u043E\u0434\u044B \u0430\u0440\u0445\u0438\u0432\u0430 \u0447\u0435\u0440\u0435\u0437 \u0444\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0443\u044E \u043C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0443"))), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("label", { className: "block text-lg font-semibold text-center mb-4" }, "\u{1F310} ", t.selectLang), /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap gap-3 justify-center" }, Object.keys(languages).map((lang) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: lang,
      onClick: () => setSelectedLanguage(lang),
      className: `px-6 py-3 rounded-xl font-medium transition-all ${selectedLanguage === lang ? "bg-gradient-to-r from-green-600 to-blue-600 text-white scale-105" : "bg-gray-100 hover:bg-gray-200 text-gray-700"}`
    },
    lang === "uz" && "\u{1F1FA}\u{1F1FF} O'zbekcha",
    lang === "ru" && "\u{1F1F7}\u{1F1FA} \u0420\u0443\u0441\u0441\u043A\u0438\u0439",
    lang === "de" && "\u{1F1E9}\u{1F1EA} Deutsch",
    lang === "en" && "\u{1F1EC}\u{1F1E7} English"
  )))), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("label", { className: "block text-lg font-semibold text-center mb-4" }, "\u{1F464} ", t.selectAge), /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap gap-3 justify-center" }, ["child", "teen", "adult"].map((age) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: age,
      onClick: () => setSelectedAge(age),
      className: `px-6 py-3 rounded-xl font-medium transition-all ${selectedAge === age ? "bg-gradient-to-r from-orange-500 to-red-500 text-white scale-105" : "bg-gray-100 hover:bg-gray-200 text-gray-700"}`
    },
    age === "child" && "\u{1F476} 0-12",
    age === "teen" && "\u{1F9D1} 13-17",
    age === "adult" && "\u{1F468} 18+"
  )))), /* @__PURE__ */ React.createElement("div", { className: "mb-8" }, /* @__PURE__ */ React.createElement("label", { className: "block text-lg font-semibold text-center mb-4" }, "\u{1F3AF} ", t.selectPurpose), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-3 gap-3" }, Object.entries(t.modules).map(([key, name]) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key,
      onClick: () => setSelectedPurpose(key),
      className: `p-4 rounded-xl font-medium transition-all text-sm ${selectedPurpose === key ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white scale-105" : "bg-gray-100 hover:bg-gray-200 text-gray-700"}`
    },
    name
  )))), /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        if (!selectedPurpose) {
          alert("\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0446\u0435\u043B\u044C / Please select a purpose");
          return;
        }
        setLoading(true);
        setTimeout(() => {
          setCurrentModule(selectedPurpose);
          setLoading(false);
        }, 2e3);
      },
      disabled: !selectedPurpose,
      className: `px-12 py-4 rounded-full text-xl font-bold transition-all ${selectedPurpose ? "bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 text-white hover:scale-110 shadow-lg" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`
    },
    "\u{1F680} ",
    t.enter
  )), loading && /* @__PURE__ */ React.createElement("div", { className: "fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50" }, /* @__PURE__ */ React.createElement("div", { className: "text-center text-white" }, /* @__PURE__ */ React.createElement("div", { className: "w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" }), /* @__PURE__ */ React.createElement("h3", { className: "text-2xl mb-4" }, "\u{1F9EC} Initializing TERRA Ecosystem..."), /* @__PURE__ */ React.createElement("p", null, "Quantum superposition activating..."))), /* @__PURE__ */ React.createElement("div", { className: "mt-8 text-center text-sm text-gray-600" }, /* @__PURE__ */ React.createElement("p", null, /* @__PURE__ */ React.createElement("strong", null, "\u{1F9EC} TERRA Ultimate Ecosystem v7.0")), /* @__PURE__ */ React.createElement("p", null, "\u0421\u043E\u0437\u0434\u0430\u043D\u043E: \u0410\u0431\u0434\u0443\u0440\u0430\u0448\u0438\u0434 \u0410\u0431\u0434\u0443\u043A\u0430\u0440\u0438\u043C\u043E\u0432 | secret.uzbek@tutamail.com"), /* @__PURE__ */ React.createElement("p", null, "DID: aiuz:did:aiuz:stakeholder:abdukarimov_aaahash1234567890"), /* @__PURE__ */ React.createElement("p", { className: "text-xs mt-2" }, "Quantum Superposition Technology | Fractal Metascience | All Archive Codes Integrated"))));
  const renderModule = () => {
    const moduleConfigs = {
      translator: {
        title: "\u{1F527} \u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A-\u041F\u0430\u0440\u0441\u0435\u0440 \u0422\u0435\u0437\u0430\u0443\u0440\u0443\u0441\u0430",
        component: /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-green-50 p-6 rounded-xl" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-4" }, "\u041C\u0443\u043B\u044C\u0442\u0438\u044F\u0437\u044B\u0447\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A"), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, /* @__PURE__ */ React.createElement(
          "input",
          {
            type: "text",
            value: translatorInput,
            onChange: (e) => setTranslatorInput(e.target.value),
            placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0441\u043B\u043E\u0432\u043E \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430...",
            className: "w-full p-3 border rounded-lg"
          }
        ), /* @__PURE__ */ React.createElement(
          "button",
          {
            onClick: handleTranslate,
            className: "px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          },
          "\u041F\u0435\u0440\u0435\u0432\u0435\u0441\u0442\u0438"
        ), translatorOutput && /* @__PURE__ */ React.createElement("div", { className: "p-4 bg-white rounded-lg border" }, /* @__PURE__ */ React.createElement("strong", null, "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442:"), " ", translatorOutput))), /* @__PURE__ */ React.createElement("div", { className: "bg-blue-50 p-6 rounded-xl" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-4" }, "\u041F\u0430\u0440\u0441\u0435\u0440 \u0430\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432"), /* @__PURE__ */ React.createElement("p", null, "\u2022 \u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 JSON, XML, CSV, YAML"), /* @__PURE__ */ React.createElement("p", null, "\u2022 Terra Core \u0432\u0430\u043B\u0438\u0434\u0430\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("p", null, "\u2022 \u0410\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u043D\u0430\u044F \u0442\u0435\u0440\u043C\u0438\u043D\u043E\u043B\u043E\u0433\u0438\u044F")))
      },
      aiDict: {
        title: "\u{1F4D6} AI-Enhanced UZ-DE \u0421\u043B\u043E\u0432\u0430\u0440\u0438",
        component: /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-blue-50 p-6 rounded-xl" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-4" }, "\u0421\u0435\u043C\u0430\u043D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0441\u0435\u0442\u0438 UZ-DE"), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, /* @__PURE__ */ React.createElement(
          "input",
          {
            type: "text",
            value: aiDictionaryQuery,
            onChange: (e) => setAiDictionaryQuery(e.target.value),
            placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0443\u0437\u0431\u0435\u043A\u0441\u043A\u043E\u0435 \u0441\u043B\u043E\u0432\u043E...",
            className: "w-full p-3 border rounded-lg"
          }
        ), /* @__PURE__ */ React.createElement(
          "button",
          {
            onClick: handleAIDictionary,
            className: "px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          },
          "\u041D\u0430\u0439\u0442\u0438 \u0432 AI-\u0441\u043B\u043E\u0432\u0430\u0440\u0435"
        ), translatorOutput && /* @__PURE__ */ React.createElement("div", { className: "p-4 bg-white rounded-lg border" }, /* @__PURE__ */ React.createElement("strong", null, "\u0421\u0435\u043C\u0430\u043D\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0441\u0435\u0442\u044C:"), " ", translatorOutput))), /* @__PURE__ */ React.createElement("div", { className: "bg-purple-50 p-6 rounded-xl" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-4" }, "AR \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F (Demo)"), /* @__PURE__ */ React.createElement("p", null, "\u2022 \u0421\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u2192 \u043C\u0433\u043D\u043E\u0432\u0435\u043D\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434"), /* @__PURE__ */ React.createElement("p", null, "\u2022 \u041A\u043E\u0440\u043F\u0443\u0441\u043D\u0430\u044F \u043C\u0435\u0442\u043E\u0434\u043E\u043B\u043E\u0433\u0438\u044F"), /* @__PURE__ */ React.createElement("p", null, "\u2022 \u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u0438")))
      },
      archPlan: {
        title: "\u{1F3D7}\uFE0F \u0410\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u043D\u044B\u0439 \u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0449\u0438\u043A \u0434\u043B\u044F \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D\u0430",
        component: /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-purple-50 p-6 rounded-xl" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-4" }, "\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0440\u043E\u0435\u043A\u0442\u0430"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block mb-2" }, "\u041F\u043B\u043E\u0449\u0430\u0434\u044C (\u043C\xB2):"), /* @__PURE__ */ React.createElement(
          "input",
          {
            type: "number",
            value: archPlanParams.area,
            onChange: (e) => setArchPlanParams({ ...archPlanParams, area: Number(e.target.value) }),
            className: "w-full p-2 border rounded"
          }
        )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block mb-2" }, "\u0411\u044E\u0434\u0436\u0435\u0442 (USD):"), /* @__PURE__ */ React.createElement(
          "input",
          {
            type: "number",
            value: archPlanParams.budget,
            onChange: (e) => setArchPlanParams({ ...archPlanParams, budget: Number(e.target.value) }),
            className: "w-full p-2 border rounded"
          }
        )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block mb-2" }, "\u0422\u0438\u043F:"), /* @__PURE__ */ React.createElement(
          "select",
          {
            value: archPlanParams.type,
            onChange: (e) => setArchPlanParams({ ...archPlanParams, type: e.target.value }),
            className: "w-full p-2 border rounded"
          },
          /* @__PURE__ */ React.createElement("option", { value: "residential" }, "\u0416\u0438\u043B\u043E\u0439"),
          /* @__PURE__ */ React.createElement("option", { value: "commercial" }, "\u041A\u043E\u043C\u043C\u0435\u0440\u0447\u0435\u0441\u043A\u0438\u0439"),
          /* @__PURE__ */ React.createElement("option", { value: "industrial" }, "\u041F\u0440\u043E\u043C\u044B\u0448\u043B\u0435\u043D\u043D\u044B\u0439")
        )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block mb-2" }, "\u041A\u043B\u0438\u043C\u0430\u0442:"), /* @__PURE__ */ React.createElement(
          "select",
          {
            value: archPlanParams.climate,
            onChange: (e) => setArchPlanParams({ ...archPlanParams, climate: e.target.value }),
            className: "w-full p-2 border rounded"
          },
          /* @__PURE__ */ React.createElement("option", { value: "tashkent" }, "\u0422\u0430\u0448\u043A\u0435\u043D\u0442"),
          /* @__PURE__ */ React.createElement("option", { value: "samarkand" }, "\u0421\u0430\u043C\u0430\u0440\u043A\u0430\u043D\u0434"),
          /* @__PURE__ */ React.createElement("option", { value: "bukhara" }, "\u0411\u0443\u0445\u0430\u0440\u0430")
        )))), /* @__PURE__ */ React.createElement("div", { className: "bg-green-50 p-6 rounded-xl" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-4" }, "\u0420\u0430\u0441\u0447\u0451\u0442 \u043F\u0440\u043E\u0435\u043A\u0442\u0430"), (() => {
          const calc = calculateArchProject();
          return /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, /* @__PURE__ */ React.createElement("p", null, /* @__PURE__ */ React.createElement("strong", null, "\u041E\u0440\u0438\u0435\u043D\u0442\u0438\u0440\u043E\u0432\u043E\u0447\u043D\u0430\u044F \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C:"), " $", calc.estimatedCost.toLocaleString()), /* @__PURE__ */ React.createElement("p", null, /* @__PURE__ */ React.createElement("strong", null, "\u042D\u043D\u0435\u0440\u0433\u043E\u043F\u043E\u0442\u0440\u0435\u0431\u043B\u0435\u043D\u0438\u0435:"), " ", calc.energyConsumption.toLocaleString(), " \u043A\u0412\u0442\u22C5\u0447/\u0433\u043E\u0434"), /* @__PURE__ */ React.createElement("p", null, /* @__PURE__ */ React.createElement("strong", null, "\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B:"), " ", calc.materials), /* @__PURE__ */ React.createElement("p", null, /* @__PURE__ */ React.createElement("strong", null, "\u0421\u0440\u043E\u043A \u0441\u0442\u0440\u043E\u0438\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430:"), " ", calc.timeline), /* @__PURE__ */ React.createElement("p", null, /* @__PURE__ */ React.createElement("strong", null, "\u041A\u043B\u0438\u043C\u0430\u0442:"), " ", calc.climate.temp, ", \u0432\u043B\u0430\u0436\u043D\u043E\u0441\u0442\u044C ", calc.climate.humidity), /* @__PURE__ */ React.createElement("div", { className: "mt-4" }, /* @__PURE__ */ React.createElement("strong", null, "\u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0438:"), /* @__PURE__ */ React.createElement("ul", { className: "list-disc ml-6 mt-2" }, calc.recommendations.map((rec, i) => /* @__PURE__ */ React.createElement("li", { key: i }, rec)))));
        })()))
      }
    };
    const config = moduleConfigs[selectedPurpose] || moduleConfigs.translator;
    return /* @__PURE__ */ React.createElement("div", { className: "min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 p-4" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-6xl mx-auto" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("h1", { className: "text-3xl font-bold text-gray-800" }, config.title), /* @__PURE__ */ React.createElement(
      "button",
      {
        onClick: () => setCurrentModule("portal"),
        className: "px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
      },
      "\u{1F504} \u041A \u0432\u044B\u0431\u043E\u0440\u0443 \u043C\u043E\u0434\u0443\u043B\u044F"
    )), /* @__PURE__ */ React.createElement("div", { className: "mt-4 p-4 bg-gray-50 rounded-lg" }, /* @__PURE__ */ React.createElement("p", null, /* @__PURE__ */ React.createElement("strong", null, "\u041A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044F:")), /* @__PURE__ */ React.createElement("p", null, "\u042F\u0437\u044B\u043A: ", selectedLanguage.toUpperCase(), " | \u0412\u043E\u0437\u0440\u0430\u0441\u0442: ", selectedAge, " | Child Safety: ", selectedAge === "child" ? "\u2705 \u0410\u043A\u0442\u0438\u0432\u043D\u0430" : "\u26A0\uFE0F \u0421\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u044B\u0439"))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6" }, config.component), /* @__PURE__ */ React.createElement("div", { className: "mt-6 text-center text-sm text-gray-600" }, /* @__PURE__ */ React.createElement("p", null, "\u{1F9EC} TERRA v7.0 | Quantum Superposition: ACTIVE | Fractal Metascience Engine"), /* @__PURE__ */ React.createElement("p", null, "Creator: \u0410\u0431\u0434\u0443\u0440\u0430\u0448\u0438\u0434 \u0410\u0431\u0434\u0443\u043A\u0430\u0440\u0438\u043C\u043E\u0432 | DID: aiuz:did:aiuz:stakeholder:abdukarimov_aaahash1234567890"))));
  };
  return currentModule === "portal" ? renderPortal() : renderModule();
};
var stdin_default = TerraUltimateEcosystem;
export {
  stdin_default as default
};
