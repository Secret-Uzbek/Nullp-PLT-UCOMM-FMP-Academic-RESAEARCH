import React, {useEffect, useState} from 'react';
export default function FractalNodePreview({ apiBase = 'http://localhost:3000' }) {
  const [nodes,setNodes]=useState([]);
  useEffect(()=>{ fetch(apiBase+'/nodes').then(r=>r.json()).then(setNodes).catch(console.error); },[apiBase]);
  return (<div>{nodes.map(n=>(<div key={n.id}><h3>{n.title}</h3><p>{n.excerpt}</p></div>))}</div>);
}