// server.js — minimal Node API for FEU registry
const express = require('express'); const cors = require('cors'); const app = express(); app.use(cors()); app.use(express.json());
const sampleNodes = [{ id: "feu-001", title: "Uzbek-mining: ore predictor", excerpt: "Model for ore grade prediction", tags: ["mining","ml"], descriptorUrl: "/descriptors/feu-001.jsonld" }];
app.get('/nodes', (req,res) => res.json(sampleNodes));
const PORT = process.env.PORT || 3000; app.listen(PORT, ()=>console.log("Server running on port", PORT));