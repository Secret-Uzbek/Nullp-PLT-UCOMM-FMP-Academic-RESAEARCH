#!/usr/bin/env python3
# process_archives.py — scan zip files in repo, extract index and redacted copies
import os, zipfile, hashlib, csv, re
print("This is the session version of process_archives.py — see session notes for full code.")