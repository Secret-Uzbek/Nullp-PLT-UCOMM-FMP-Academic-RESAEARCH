#!/usr/bin/env python3
# publish_to_zenodo.py — uses Zenodo API to create deposit (session version)
print("Publish to Zenodo script (see session for full code and token usage).")