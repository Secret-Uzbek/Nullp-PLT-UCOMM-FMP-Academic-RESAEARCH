#!/usr/bin/env python3
# generate_metadata.py — create JSON-LD, BibTeX, RIS
print("Metadata generator — session scaffold.")