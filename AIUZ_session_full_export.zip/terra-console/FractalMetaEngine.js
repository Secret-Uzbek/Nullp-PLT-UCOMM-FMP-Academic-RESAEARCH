// FractalMetaEngine.js (excerpt)
const FractalMetaEngine = (function(){
  function indexFiles(filesStore){ /*...*/ }
  function generateCatalogMetadata(artifacts){ /*...*/ }
  function makeFEUDescriptors(artifacts){ /*...*/ }
  return { indexFiles, generateCatalogMetadata, makeFEUDescriptors };
})();