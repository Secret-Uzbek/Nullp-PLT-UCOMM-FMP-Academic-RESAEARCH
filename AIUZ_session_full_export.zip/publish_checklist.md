# Publish Checklist (AIUZ NULLO PLT UCOMM FMP)
- Add 3+ peer-reviewed references for key claims
- Redact secrets
- Confirm license and authorship
- Compile LaTeX and attach PDFs