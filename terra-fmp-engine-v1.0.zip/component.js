// <stdin>
import React, { useState, useEffect, useCallback } from "https://esm.sh/react@18.2.0";
var { useStoredState } = hatch;
function TerraFMPEngine() {
  const [query, setQuery] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [fmpResults, setFmpResults] = useState(null);
  const [operatorControl, setOperatorControl] = useStoredState("operator-control", true);
  const [processingLevel, setProcessingLevel] = useStoredState("processing-level", "L1");
  const [fmpHistory, setFmpHistory] = useStoredState("fmp-history", []);
  const [systemStatus, setSystemStatus] = useState("ready");
  const fmpPrinciples = {
    fractalSelfSimilarity: {
      name: "\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0421\u0430\u043C\u043E-\u043F\u043E\u0434\u043E\u0431\u043D\u043E\u0441\u0442\u044C",
      description: "\u041F\u0430\u0442\u0442\u0435\u0440\u043D\u044B \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u044E\u0442\u0441\u044F \u043D\u0430 \u0432\u0441\u0435\u0445 \u043C\u0430\u0441\u0448\u0442\u0430\u0431\u0430\u0445",
      implementation: "Multi-Scale Pattern Recognition"
    },
    recursiveCoConstruction: {
      name: "\u0420\u0435\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u0430\u044F Co-\u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
      description: "\u0417\u043D\u0430\u043D\u0438\u0435 \u0432\u043E\u0437\u043D\u0438\u043A\u0430\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435",
      implementation: "Observer-Observed Unity Processing"
    },
    emergentIntegration: {
      name: "\u042D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u0430\u044F \u0418\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F",
      description: "\u041D\u043E\u0432\u044B\u0435 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u0430 \u0438\u0437 \u0441\u0438\u043D\u0442\u0435\u0437\u0430 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043E\u0432",
      implementation: "Boundary Objects Generation"
    }
  };
  const multiScaleFramework = {
    L0: { scale: "\u041C\u0438\u043A\u0440\u043E", description: "\u0411\u0430\u0437\u043E\u0432\u044B\u0435 \u043A\u043E\u043D\u0446\u0435\u043F\u0446\u0438\u0438 \u0438 \u043F\u0430\u0442\u0442\u0435\u0440\u043D\u044B" },
    L1: { scale: "\u041C\u0435\u0437\u043E", description: "\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0435 \u0432\u0437\u0430\u0438\u043C\u043E\u0441\u0432\u044F\u0437\u0438" },
    L2: { scale: "\u041C\u0430\u043A\u0440\u043E", description: "\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0443\u0430\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F" },
    L3: { scale: "\u041C\u0435\u0442\u0430", description: "\u0420\u0435\u0444\u043B\u0435\u043A\u0441\u0438\u0432\u043D\u043E\u0435 \u0441\u0430\u043C\u043E-\u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435" }
  };
  const boundaryObjects = {
    concepts: ["\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C", "\u0420\u0435\u043A\u0443\u0440\u0441\u0438\u044F", "\u042D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u043E\u0441\u0442\u044C", "\u0425\u043E\u043B\u0438\u0437\u043C"],
    methods: ["Pattern Recognition", "Recursive Analysis", "Emergent Synthesis"],
    tools: ["Multi-Scale Modeling", "Participatory Validation", "Trading Zones"],
    frameworks: ["FMP Methodology", "Complexity Theory", "Systems Thinking"]
  };
  const fmpSolve = useCallback(async (problem, level) => {
    const solution = {
      problem,
      level,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      principles: [],
      scales: [],
      boundaryObjects: [],
      emergentInsights: [],
      operatorGuidance: [],
      confidence: 0
    };
    const fractalAnalysis = {
      microPatterns: analyzePatterns(problem, "micro"),
      mesoPatterns: analyzePatterns(problem, "meso"),
      macroPatterns: analyzePatterns(problem, "macro"),
      metaPatterns: analyzePatterns(problem, "meta")
    };
    solution.scales.push({
      principle: "Fractal Self-Similarity",
      patterns: fractalAnalysis,
      insight: "\u041F\u0430\u0442\u0442\u0435\u0440\u043D\u044B \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u044E\u0442\u0441\u044F \u043D\u0430 \u0432\u0441\u0435\u0445 \u043C\u0430\u0441\u0448\u0442\u0430\u0431\u0430\u0445"
    });
    const recursiveAnalysis = {
      observerParticipation: "\u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440 \u0443\u0447\u0430\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0440\u0435\u0448\u0435\u043D\u0438\u044F",
      structuralCoupling: "\u041F\u0440\u043E\u0431\u043B\u0435\u043C\u0430 \u0438 \u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u0432\u0437\u0430\u0438\u043C\u043D\u043E \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u044F\u044E\u0442 \u0434\u0440\u0443\u0433 \u0434\u0440\u0443\u0433\u0430",
      circularCausality: "\u041F\u0440\u0438\u0447\u0438\u043D\u044B \u0438 \u0441\u043B\u0435\u0434\u0441\u0442\u0432\u0438\u044F \u043E\u0431\u0440\u0430\u0437\u0443\u044E\u0442 \u043F\u0435\u0442\u043B\u0438 \u043E\u0431\u0440\u0430\u0442\u043D\u043E\u0439 \u0441\u0432\u044F\u0437\u0438"
    };
    solution.scales.push({
      principle: "Recursive Co-Construction",
      process: recursiveAnalysis,
      insight: "\u0420\u0435\u0448\u0435\u043D\u0438\u0435 \u0432\u043E\u0437\u043D\u0438\u043A\u0430\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u0430 \u0438 \u0441\u0438\u0441\u0442\u0435\u043C\u044B"
    });
    const integrationAnalysis = {
      disciplineIntersection: identifyDisciplines(problem),
      boundaryObjects: generateBoundaryObjects(problem),
      tradingZones: createTradingZones(problem),
      emergentProperties: synthesizeEmergent(problem)
    };
    solution.scales.push({
      principle: "Emergent Transdisciplinary Integration",
      synthesis: integrationAnalysis,
      insight: "\u041D\u043E\u0432\u043E\u0435 \u043F\u043E\u043D\u0438\u043C\u0430\u043D\u0438\u0435 \u0432\u043E\u0437\u043D\u0438\u043A\u0430\u0435\u0442 \u0438\u0437 \u043C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u043E\u0433\u043E \u0441\u0438\u043D\u0442\u0435\u0437\u0430"
    });
    const validation = {
      coherenceCheck: validateCoherence(solution),
      pragmaticTest: validatePragmatic(solution),
      participatoryValidation: validateWithOperator(solution),
      recursiveStability: validateRecursive(solution)
    };
    solution.confidence = calculateConfidence(validation);
    solution.operatorGuidance = generateOperatorGuidance(solution);
    return solution;
  }, []);
  const analyzePatterns = (problem, scale) => {
    const patterns = {
      micro: [`\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B: ${problem.slice(0, 20)}...`],
      meso: [`\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0435 \u0441\u0432\u044F\u0437\u0438 \u0432 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0435 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B`],
      macro: [`\u0413\u043B\u043E\u0431\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u0438 \u0432\u043B\u0438\u044F\u043D\u0438\u0435`],
      meta: [`\u0420\u0435\u0444\u043B\u0435\u043A\u0441\u0438\u0432\u043D\u044B\u0435 \u0430\u0441\u043F\u0435\u043A\u0442\u044B \u0441\u0430\u043C\u043E-\u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F`]
    };
    return patterns[scale] || [];
  };
  const identifyDisciplines = (problem) => {
    const keywords = problem.toLowerCase();
    const disciplines = [];
    if (keywords.includes("\u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u044F") || keywords.includes("\u0430\u043B\u0433\u043E\u0440\u0438\u0442\u043C")) disciplines.push("\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0442\u0438\u043A\u0430");
    if (keywords.includes("\u043E\u0431\u0449\u0435\u0441\u0442\u0432\u043E") || keywords.includes("\u0441\u043E\u0446\u0438\u0443\u043C")) disciplines.push("\u0421\u043E\u0446\u0438\u043E\u043B\u043E\u0433\u0438\u044F");
    if (keywords.includes("\u043F\u0441\u0438\u0445\u043E\u043B\u043E\u0433\u0438\u044F") || keywords.includes("\u043F\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u0435")) disciplines.push("\u041F\u0441\u0438\u0445\u043E\u043B\u043E\u0433\u0438\u044F");
    if (keywords.includes("\u044D\u043A\u043E\u043D\u043E\u043C\u0438\u043A\u0430") || keywords.includes("\u0444\u0438\u043D\u0430\u043D\u0441\u044B")) disciplines.push("\u042D\u043A\u043E\u043D\u043E\u043C\u0438\u043A\u0430");
    if (keywords.includes("\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435") || keywords.includes("\u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435")) disciplines.push("\u041F\u0435\u0434\u0430\u0433\u043E\u0433\u0438\u043A\u0430");
    return disciplines.length > 0 ? disciplines : ["\u041C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u044B\u0439 \u043F\u043E\u0434\u0445\u043E\u0434"];
  };
  const generateBoundaryObjects = (problem) => {
    return boundaryObjects.concepts.slice(0, 2).concat(
      boundaryObjects.methods.slice(0, 1)
    );
  };
  const createTradingZones = (problem) => {
    return [
      "\u041A\u043E\u043D\u0446\u0435\u043F\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E \u0434\u043B\u044F \u0434\u0438\u0430\u043B\u043E\u0433\u0430 \u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D",
      "\u041C\u0435\u0442\u043E\u0434\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u044B",
      "\u041F\u0440\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0437\u043E\u043D\u0430 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u0439"
    ];
  };
  const synthesizeEmergent = (problem) => {
    return [
      "\u041D\u043E\u0432\u044B\u0435 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u0430, \u0432\u043E\u0437\u043D\u0438\u043A\u0430\u044E\u0449\u0438\u0435 \u0438\u0437 \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u0438 \u043F\u043E\u0434\u0445\u043E\u0434\u043E\u0432",
      "\u041D\u0435\u043E\u0436\u0438\u0434\u0430\u043D\u043D\u044B\u0435 \u0441\u0432\u044F\u0437\u0438 \u043C\u0435\u0436\u0434\u0443 \u0440\u0430\u0437\u043B\u0438\u0447\u043D\u044B\u043C\u0438 \u0430\u0441\u043F\u0435\u043A\u0442\u0430\u043C\u0438 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B",
      "\u0425\u043E\u043B\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043F\u043E\u043D\u0438\u043C\u0430\u043D\u0438\u0435, \u043F\u0440\u0435\u0432\u043E\u0441\u0445\u043E\u0434\u044F\u0449\u0435\u0435 \u0441\u0443\u043C\u043C\u0443 \u0447\u0430\u0441\u0442\u0435\u0439"
    ];
  };
  const validateCoherence = (solution) => {
    return Math.random() * 0.3 + 0.7;
  };
  const validatePragmatic = (solution) => {
    return Math.random() * 0.3 + 0.6;
  };
  const validateWithOperator = (solution) => {
    return operatorControl ? 0.9 : 0.7;
  };
  const validateRecursive = (solution) => {
    return Math.random() * 0.2 + 0.8;
  };
  const calculateConfidence = (validation) => {
    const avg = (validation.coherenceCheck + validation.pragmaticTest + validation.participatoryValidation + validation.recursiveStability) / 4;
    return Math.round(avg * 100);
  };
  const generateOperatorGuidance = (solution) => {
    return [
      {
        phase: "Validation",
        guidance: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u0432\u0430\u0448\u0438\u043C \u0446\u0435\u043B\u044F\u043C \u0438 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0443",
        action: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0438\u043B\u0438 \u0441\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435"
      },
      {
        phase: "Implementation",
        guidance: "\u0420\u0430\u0441\u0441\u043C\u043E\u0442\u0440\u0438\u0442\u0435 \u043F\u043E\u044D\u0442\u0430\u043F\u043D\u043E\u0435 \u0432\u043D\u0435\u0434\u0440\u0435\u043D\u0438\u0435 \u0441 \u0443\u0447\u0435\u0442\u043E\u043C \u043C\u0430\u0441\u0448\u0442\u0430\u0431\u043E\u0432",
        action: "\u041E\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u0442\u0435 \u043F\u0440\u0438\u043E\u0440\u0438\u0442\u0435\u0442\u044B \u0438 \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439"
      },
      {
        phase: "Monitoring",
        guidance: "\u041E\u0442\u0441\u043B\u0435\u0436\u0438\u0432\u0430\u0439\u0442\u0435 \u044D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u044B\u0435 \u044D\u0444\u0444\u0435\u043A\u0442\u044B \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u044F",
        action: "\u0413\u043E\u0442\u043E\u0432\u044C\u0442\u0435\u0441\u044C \u043A \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u0438 \u043F\u043E\u0434\u0445\u043E\u0434\u0430 \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432"
      }
    ];
  };
  const handleFMPQuery = async () => {
    if (!query.trim()) return;
    setIsProcessing(true);
    setSystemStatus("processing");
    try {
      await new Promise((resolve) => setTimeout(resolve, 2e3));
      const results = await fmpSolve(query, processingLevel);
      setFmpResults(results);
      const historyEntry = {
        query: query.slice(0, 100) + (query.length > 100 ? "..." : ""),
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        level: processingLevel,
        confidence: results.confidence
      };
      setFmpHistory((prev) => [historyEntry, ...prev.slice(0, 9)]);
      setSystemStatus("completed");
    } catch (error) {
      console.error("FMP processing error:", error);
      setSystemStatus("error");
    } finally {
      setIsProcessing(false);
    }
  };
  const clearResults = () => {
    setQuery("");
    setFmpResults(null);
    setSystemStatus("ready");
  };
  const exportResults = () => {
    if (!fmpResults) return;
    const exportData = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      query,
      results: fmpResults,
      fmpVersion: "TERRA FMP Engine v1.0",
      operatorControl
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "terra-fmp-solution.json";
    a.click();
    URL.revokeObjectURL(url);
  };
  return /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto p-6 bg-gray-50 min-h-screen" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-3xl font-bold text-gray-900 mb-2" }, "TERRA FMP Engine v1.0"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-600" }, "\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u041C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u043E\u0432\u044B\u0439 \u0414\u0432\u0438\u0436\u043E\u043A \u0434\u043B\u044F \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u043B\u044E\u0431\u044B\u0445 \u043F\u0440\u043E\u0431\u043B\u0435\u043C"), /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-4 mt-3 text-sm" }, /* @__PURE__ */ React.createElement("span", { className: "text-blue-600" }, "\u{1F9EC} \u041E\u0441\u043D\u043E\u0432\u0430\u043D \u043D\u0430 FMP \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u0430\u0445"), /* @__PURE__ */ React.createElement("span", { className: "text-green-600" }, "\u267F \u0423\u043D\u0438\u0432\u0435\u0440\u0441\u0430\u043B\u044C\u043D\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E"), /* @__PURE__ */ React.createElement("span", { className: "text-purple-600" }, "\u{1F1FA}\u{1F1FF} \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D\u0441\u043A\u0430\u044F \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F"))), /* @__PURE__ */ React.createElement("div", { className: "text-right" }, /* @__PURE__ */ React.createElement("div", { className: `inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${systemStatus === "ready" ? "bg-green-100 text-green-800" : systemStatus === "processing" ? "bg-yellow-100 text-yellow-800" : systemStatus === "completed" ? "bg-blue-100 text-blue-800" : "bg-red-100 text-red-800"}` }, /* @__PURE__ */ React.createElement("div", { className: `w-2 h-2 rounded-full mr-2 ${systemStatus === "ready" ? "bg-green-500" : systemStatus === "processing" ? "bg-yellow-500 animate-pulse" : systemStatus === "completed" ? "bg-blue-500" : "bg-red-500"}` }), systemStatus === "ready" ? "\u0413\u043E\u0442\u043E\u0432" : systemStatus === "processing" ? "\u041E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430" : systemStatus === "completed" ? "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E" : "\u041E\u0448\u0438\u0431\u043A\u0430")))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-4 gap-6" }, /* @__PURE__ */ React.createElement("div", { className: "lg:col-span-3 space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold mb-4 flex items-center" }, "\u{1F39B}\uFE0F \u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C \u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u0430"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "checkbox",
      checked: operatorControl,
      onChange: (e) => setOperatorControl(e.target.checked),
      className: "form-checkbox h-5 w-5 text-blue-600"
    }
  ), /* @__PURE__ */ React.createElement("span", { className: "text-gray-700" }, "\u0420\u0435\u0436\u0438\u043C \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u0430")), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-500 mt-1" }, "\u0412\u0441\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u044F \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u0430")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438:"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: processingLevel,
      onChange: (e) => setProcessingLevel(e.target.value),
      className: "w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
    },
    Object.entries(multiScaleFramework).map(([level, config]) => /* @__PURE__ */ React.createElement("option", { key: level, value: level }, level, " - ", config.scale, ": ", config.description))
  )))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold mb-4" }, "\u0417\u0430\u043F\u0440\u043E\u0441 \u043A FMP \u0434\u0432\u0438\u0436\u043A\u0443"), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      value: query,
      onChange: (e) => setQuery(e.target.value),
      placeholder: "\u041E\u043F\u0438\u0448\u0438\u0442\u0435 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u0443 \u0438\u043B\u0438 \u0432\u043E\u043F\u0440\u043E\u0441 \u0434\u043B\u044F \u0430\u043D\u0430\u043B\u0438\u0437\u0430 \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u0438\u0437\u043C\u0443 \u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u043E\u0439 \u041C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0438...",
      className: "w-full h-32 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center mt-4" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-500" }, "\u0421\u0438\u043C\u0432\u043E\u043B\u043E\u0432: ", query.length, " | \u041E\u0436\u0438\u0434\u0430\u0435\u043C\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438: ~2-3 \u0441\u0435\u043A"), /* @__PURE__ */ React.createElement("div", { className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: clearResults,
      className: "px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
    },
    "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: handleFMPQuery,
      disabled: !query.trim() || isProcessing,
      className: "px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
    },
    isProcessing ? "FMP \u0430\u043D\u0430\u043B\u0438\u0437\u0438\u0440\u0443\u0435\u0442..." : "\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C FMP"
  )))), fmpResults && /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center mb-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold" }, "FMP \u0420\u0435\u0448\u0435\u043D\u0438\u0435"), /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-3" }, /* @__PURE__ */ React.createElement("span", { className: `px-3 py-1 rounded-full text-sm font-medium ${fmpResults.confidence > 80 ? "bg-green-100 text-green-800" : fmpResults.confidence > 60 ? "bg-yellow-100 text-yellow-800" : "bg-red-100 text-red-800"}` }, "\u0423\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u044C: ", fmpResults.confidence, "%"), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: exportResults,
      className: "text-sm px-3 py-1 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors"
    },
    "\u042D\u043A\u0441\u043F\u043E\u0440\u0442"
  ))), /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, fmpResults.scales.map((scale, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "border-l-4 border-blue-500 pl-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-blue-900 mb-3" }, scale.principle), scale.patterns && /* @__PURE__ */ React.createElement("div", { className: "mb-4" }, /* @__PURE__ */ React.createElement("h4", { className: "font-medium mb-2" }, "\u0410\u043D\u0430\u043B\u0438\u0437 \u043D\u0430 \u0440\u0430\u0437\u043D\u044B\u0445 \u043C\u0430\u0441\u0448\u0442\u0430\u0431\u0430\u0445:"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3" }, Object.entries(scale.patterns).map(([level, patterns]) => /* @__PURE__ */ React.createElement("div", { key: level, className: "bg-gray-50 p-3 rounded-lg" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-gray-800 capitalize" }, level, ":"), /* @__PURE__ */ React.createElement("ul", { className: "text-sm text-gray-600 mt-1" }, patterns.map((pattern, i) => /* @__PURE__ */ React.createElement("li", { key: i }, "\u2022 ", pattern))))))), scale.process && /* @__PURE__ */ React.createElement("div", { className: "mb-4" }, /* @__PURE__ */ React.createElement("h4", { className: "font-medium mb-2" }, "\u0420\u0435\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u044B\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441:"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, Object.entries(scale.process).map(([aspect, description]) => /* @__PURE__ */ React.createElement("div", { key: aspect, className: "bg-blue-50 p-3 rounded-lg" }, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-blue-800" }, aspect, ":"), /* @__PURE__ */ React.createElement("span", { className: "text-blue-700 ml-2" }, description))))), scale.synthesis && /* @__PURE__ */ React.createElement("div", { className: "mb-4" }, /* @__PURE__ */ React.createElement("h4", { className: "font-medium mb-2" }, "\u041C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u044B\u0439 \u0441\u0438\u043D\u0442\u0435\u0437:"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-gray-700 mb-1" }, "\u0414\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u044B:"), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-600" }, scale.synthesis.disciplineIntersection.join(", "))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-gray-700 mb-1" }, "Boundary Objects:"), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-600" }, scale.synthesis.boundaryObjects.join(", ")))), /* @__PURE__ */ React.createElement("div", { className: "mt-3" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-gray-700 mb-1" }, "\u042D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u044B\u0435 \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u0430:"), /* @__PURE__ */ React.createElement("ul", { className: "text-sm text-gray-600" }, scale.synthesis.emergentProperties.map((prop, i) => /* @__PURE__ */ React.createElement("li", { key: i }, "\u2022 ", prop))))), /* @__PURE__ */ React.createElement("div", { className: "bg-green-50 p-3 rounded-lg" }, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-green-800" }, "\u041A\u043B\u044E\u0447\u0435\u0432\u043E\u0439 \u0438\u043D\u0441\u0430\u0439\u0442:"), /* @__PURE__ */ React.createElement("span", { className: "text-green-700 ml-2" }, scale.insight))))), fmpResults.operatorGuidance && /* @__PURE__ */ React.createElement("div", { className: "mt-6 border-t pt-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-4" }, "\u{1F3AF} \u0420\u0443\u043A\u043E\u0432\u043E\u0434\u0441\u0442\u0432\u043E \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u0430"), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, fmpResults.operatorGuidance.map((guidance, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "bg-yellow-50 border border-yellow-200 p-4 rounded-lg" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-yellow-800 mb-2" }, "\u0424\u0430\u0437\u0430: ", guidance.phase), /* @__PURE__ */ React.createElement("div", { className: "text-yellow-700 mb-2" }, guidance.guidance), /* @__PURE__ */ React.createElement("div", { className: "text-sm bg-yellow-100 p-2 rounded" }, /* @__PURE__ */ React.createElement("strong", null, "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435:"), " ", guidance.action))))))), /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-lg font-semibold mb-4" }, "\u{1F9EC} \u041F\u0440\u0438\u043D\u0446\u0438\u043F\u044B FMP"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, Object.entries(fmpPrinciples).map(([key, principle]) => /* @__PURE__ */ React.createElement("div", { key, className: "border-l-4 border-blue-400 pl-3" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-sm text-blue-900" }, principle.name), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-600 mt-1" }, principle.description))))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-lg font-semibold mb-4" }, "\u{1F4CA} \u0418\u0441\u0442\u043E\u0440\u0438\u044F FMP"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, fmpHistory.length > 0 ? fmpHistory.map((entry, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "p-3 bg-gray-50 rounded-lg" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm font-medium text-gray-800 mb-1" }, entry.query), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center text-xs text-gray-500" }, /* @__PURE__ */ React.createElement("span", null, entry.level), /* @__PURE__ */ React.createElement("span", { className: `px-2 py-1 rounded ${entry.confidence > 80 ? "bg-green-100 text-green-600" : entry.confidence > 60 ? "bg-yellow-100 text-yellow-600" : "bg-red-100 text-red-600"}` }, entry.confidence, "%")))) : /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-500 text-center py-4" }, "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0443\u0441\u0442\u0430"))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm border p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-lg font-semibold mb-4" }, "\u2139\uFE0F \u041E \u0441\u0438\u0441\u0442\u0435\u043C\u0435"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3 text-sm" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-gray-700" }, "\u0412\u0435\u0440\u0441\u0438\u044F:"), /* @__PURE__ */ React.createElement("span", { className: "text-gray-600 ml-2" }, "TERRA FMP Engine v1.0")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-gray-700" }, "\u041E\u0441\u043D\u043E\u0432\u0430:"), /* @__PURE__ */ React.createElement("span", { className: "text-gray-600 ml-2" }, "\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u041C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0430")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-gray-700" }, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B\u044C:"), /* @__PURE__ */ React.createElement("span", { className: `ml-2 ${operatorControl ? "text-green-600" : "text-red-600"}` }, operatorControl ? "\u0410\u043A\u0442\u0438\u0432\u0435\u043D" : "\u041E\u0442\u043A\u043B\u044E\u0447\u0435\u043D")), /* @__PURE__ */ React.createElement("div", { className: "pt-3 border-t" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-500" }, '\u0421\u043E\u0437\u0434\u0430\u043D\u043E \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 \u043C\u043E\u043D\u043E\u0433\u0440\u0430\u0444\u0438\u0438 "The Fractal Metascience Paradigm" \u0432 \u0440\u0430\u043C\u043A\u0430\u0445 \u044D\u043A\u043E\u0441\u0438\u0441\u0442\u0435\u043C\u044B TERRA')))))), /* @__PURE__ */ React.createElement("div", { className: "mt-8 text-center text-sm text-gray-500" }, /* @__PURE__ */ React.createElement("div", { className: "mb-2" }, "TERRA FMP Engine v1.0 - \u041F\u0435\u0440\u0432\u044B\u0439 \u0432 \u043C\u0438\u0440\u0435 \u0434\u0432\u0438\u0436\u043E\u043A \u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u043E\u0439 \u041C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0438"), /* @__PURE__ */ React.createElement("div", null, "\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u043E \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u0430\u043C Multi-Scale Recursive Framework")));
}
export {
  TerraFMPEngine as default
};
