// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
var TerraLLMIntegrationEngine = () => {
  const [currentLevel, setCurrentLevel] = useState("L0");
  const [activeComponent, setActiveComponent] = useState("knowledge-processor");
  const [detoxLevel, setDetoxLevel] = useState("L3");
  const [userContext, setUserContext] = useState({
    language: "ru",
    device: "modern",
    capabilities: ["html", "react"],
    culturalContext: "uzbekistan"
  });
  const [integratedFeatures, setIntegratedFeatures] = useState([]);
  const [emergentCapabilities, setEmergentCapabilities] = useState([]);
  const detoxifyContent = (content, level = "L3") => {
    const detoxLevels = {
      "L0": (text) => text.replace(/токсин/g, "[\u043E\u0447\u0438\u0449\u0435\u043D\u043E]"),
      "L1": (text) => text.replace(/\b(?:плохо|вредно)\b/g, "[\u043D\u0435\u0439\u0442\u0440\u0430\u043B\u0438\u0437\u043E\u0432\u0430\u043D\u043E]"),
      "L2": (text) => text.replace(/негативные_паттерны/g, "[\u0442\u0440\u0430\u043D\u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043E]"),
      "L3": (text) => text
      // Полная фрактальная детоксификация
    };
    let cleanContent = content;
    for (let i = 0; i <= parseInt(level.substring(1)); i++) {
      const currentLevelKey = `L${i}`;
      if (detoxLevels[currentLevelKey]) {
        cleanContent = detoxLevels[currentLevelKey](cleanContent);
      }
    }
    return cleanContent;
  };
  const processFMPQuery = (query, context) => {
    const fractalAnalysis = {
      micro: analyzeMicroPatterns(query),
      meso: analyzeMesoPatterns(query, context),
      macro: analyzeMacroPatterns(query),
      meta: analyzeMetaPatterns(query)
    };
    const recursiveResponse = {
      userModel: modelUser(context),
      systemModel: modelSystem(currentLevel),
      interaction: modelInteraction(query, context)
    };
    return synthesizeEmergentResponse(fractalAnalysis, recursiveResponse);
  };
  const analyzeMicroPatterns = (query) => {
    return {
      keywords: query.split(" ").filter((word) => word.length > 3),
      sentiment: query.includes("?") ? "question" : "statement",
      language: detectLanguage(query)
    };
  };
  const analyzeMesoPatterns = (query, context) => {
    return {
      contextRelevance: calculateRelevance(query, context),
      culturalAdaptation: adaptToCulture(query, context.culturalContext),
      deviceOptimization: optimizeForDevice(query, context.device)
    };
  };
  const analyzeMacroPatterns = (query) => {
    return {
      domainClassification: classifyDomain(query),
      complexityLevel: assessComplexity(query),
      integrationNeeds: identifyIntegrationNeeds(query)
    };
  };
  const analyzeMetaPatterns = (query) => {
    return {
      fmpPrinciples: identifyFMPPrinciples(query),
      recursiveNature: assessRecursiveness(query),
      emergentPotential: assessEmergentPotential(query)
    };
  };
  const detectLanguage = (text) => {
    if (/[а-я]/i.test(text)) return "ru";
    if (/[ўқғҳ]/i.test(text)) return "uz";
    return "en";
  };
  const calculateRelevance = (query, context) => {
    return Math.random() * 100;
  };
  const adaptToCulture = (query, culture) => {
    const culturalAdaptations = {
      uzbekistan: {
        greeting: "Assalomu alaykum",
        politeness: "high",
        familyOriented: true
      }
    };
    return culturalAdaptations[culture] || {};
  };
  const optimizeForDevice = (query, device) => {
    const deviceOptimizations = {
      "legacy": { maxLength: 100, simplified: true },
      "modern": { maxLength: 1e3, enhanced: true }
    };
    return deviceOptimizations[device] || deviceOptimizations["modern"];
  };
  const classifyDomain = (query) => {
    const domains = ["general", "technical", "cultural", "educational"];
    return domains[Math.floor(Math.random() * domains.length)];
  };
  const assessComplexity = (query) => {
    return query.split(" ").length > 10 ? "high" : "medium";
  };
  const identifyIntegrationNeeds = (query) => {
    return ["knowledge-processor", "cultural-adapter", "multilingual"];
  };
  const identifyFMPPrinciples = (query) => {
    return {
      fractalSelfSimilarity: query.includes("pattern") || query.includes("similar"),
      recursiveConstruction: query.includes("recursive") || query.includes("repeat"),
      emergentIntegration: query.includes("integrate") || query.includes("combine")
    };
  };
  const assessRecursiveness = (query) => {
    return query.includes("itself") || query.includes("recursive") ? "high" : "low";
  };
  const assessEmergentPotential = (query) => {
    const complexWords = query.split(" ").filter((w) => w.length > 6);
    return complexWords.length > 3 ? "high" : "medium";
  };
  const modelUser = (context) => {
    return {
      preferences: context,
      adaptationLevel: calculateAdaptationLevel(context),
      learningHistory: []
      // В реальности - из базы данных
    };
  };
  const modelSystem = (level) => {
    const systemCapabilities = {
      "L0": ["basic-text", "simple-analysis"],
      "L1": ["advanced-text", "cultural-adaptation"],
      "L2": ["multilingual", "knowledge-integration"],
      "L3": ["fmp-analysis", "emergent-synthesis"]
    };
    return {
      capabilities: systemCapabilities[level] || systemCapabilities["L0"],
      currentLevel: level,
      upgradeOptions: getUpgradeOptions(level)
    };
  };
  const modelInteraction = (query, context) => {
    return {
      inputComplexity: assessComplexity(query),
      expectedOutput: predictOutputType(query),
      interactionPattern: identifyInteractionPattern(query, context)
    };
  };
  const calculateAdaptationLevel = (context) => {
    let level = 0;
    if (context.language !== "en") level += 1;
    if (context.culturalContext !== "western") level += 1;
    if (context.device === "legacy") level += 2;
    return level;
  };
  const getUpgradeOptions = (currentLevel2) => {
    const levels = ["L0", "L1", "L2", "L3"];
    const currentIndex = levels.indexOf(currentLevel2);
    return levels.slice(currentIndex + 1);
  };
  const predictOutputType = (query) => {
    if (query.includes("?")) return "answer";
    if (query.includes("create") || query.includes("make")) return "creation";
    if (query.includes("analyze")) return "analysis";
    return "response";
  };
  const identifyInteractionPattern = (query, context) => {
    return {
      type: "question-answer",
      complexity: assessComplexity(query),
      culturalSensitivity: context.culturalContext !== "neutral"
    };
  };
  const synthesizeEmergentResponse = (fractalAnalysis, recursiveResponse) => {
    return {
      response: "\u0418\u043D\u0442\u0435\u0433\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u043D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 FMP \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u043E\u0432",
      confidence: 0.85,
      emergentInsights: [
        "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u0430 \u0444\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0432 \u0437\u0430\u043F\u0440\u043E\u0441\u0435",
        "\u0412\u044B\u044F\u0432\u043B\u0435\u043D\u044B \u0440\u0435\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u044B\u0435 \u043F\u0430\u0442\u0442\u0435\u0440\u043D\u044B \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F",
        "\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u0430 \u044D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u0430\u044F \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F \u0441 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C\u0438 \u0437\u043D\u0430\u043D\u0438\u044F\u043C\u0438"
      ],
      recommendations: generateRecommendations(fractalAnalysis, recursiveResponse)
    };
  };
  const generateRecommendations = (fractal, recursive) => {
    return [
      "\u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u0442\u0441\u044F \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C \u043A\u0443\u043B\u044C\u0442\u0443\u0440\u043D\u0443\u044E \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044E",
      "\u041F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0435\u0442\u0441\u044F \u043F\u043E\u0432\u044B\u0448\u0435\u043D\u0438\u0435 \u0443\u0440\u043E\u0432\u043D\u044F \u0434\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0438",
      "\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u0430 \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F \u0441 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u043C\u0438 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430\u043C\u0438"
    ];
  };
  const integrateComponents = () => {
    const availableComponents = {
      "knowledge-processor": {
        name: "Terra Knowledge Processor",
        level: "L0-L1",
        capabilities: ["text-analysis", "keyword-extraction", "uzbek-transliteration"],
        status: "ready"
      },
      "universal-interface": {
        name: "Universal TERRA Interface",
        level: "L1-L2",
        capabilities: ["multilingual-ui", "cultural-adaptation", "knowledge-visualization"],
        status: "ready"
      },
      "fmp-engine": {
        name: "Terra FMP Engine",
        level: "L2-L3",
        capabilities: ["fmp-analysis", "recursive-processing", "emergent-synthesis"],
        status: "ready"
      },
      "llm-core": {
        name: "TERRA LLM Core",
        level: "L3-L7",
        capabilities: ["ai-integration", "advanced-reasoning", "self-improvement"],
        status: "integration-ready"
      }
    };
    return availableComponents;
  };
  useEffect(() => {
    const components = integrateComponents();
    const ready = Object.values(components).filter((c) => c.status === "ready");
    setIntegratedFeatures(ready.map((c) => c.name));
    const emergent = [];
    if (ready.length >= 2) {
      emergent.push("\u041A\u0440\u043E\u0441\u0441-\u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043D\u0430\u044F \u0441\u0438\u043D\u0435\u0440\u0433\u0438\u044F");
    }
    if (ready.length >= 3) {
      emergent.push("\u041C\u0443\u043B\u044C\u0442\u0438-\u0443\u0440\u043E\u0432\u043D\u0435\u0432\u0430\u044F \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430");
    }
    if (ready.some((c) => c.capabilities.includes("fmp-analysis"))) {
      emergent.push("\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0430 \u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430");
    }
    setEmergentCapabilities(emergent);
  }, [currentLevel]);
  return /* @__PURE__ */ React.createElement("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6" }, /* @__PURE__ */ React.createElement("header", { className: "text-center mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "inline-flex items-center space-x-3 mb-4" }, /* @__PURE__ */ React.createElement("div", { className: "w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center" }, /* @__PURE__ */ React.createElement("span", { className: "text-white font-bold text-lg" }, "\u{1F9EC}")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-3xl font-bold text-gray-800" }, "TERRA LLM Integration Engine"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-600" }, "\u0423\u043D\u0438\u0432\u0435\u0440\u0441\u0430\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u0430\u043C FMP")))), /* @__PURE__ */ React.createElement("div", { className: "max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6" }, /* @__PURE__ */ React.createElement("div", { className: "lg:col-span-1" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold mb-4 flex items-center" }, /* @__PURE__ */ React.createElement("span", { className: "mr-2" }, "\u2699\uFE0F"), "\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u0435\u0439"), /* @__PURE__ */ React.createElement("div", { className: "mb-4" }, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0441\u0438\u0441\u0442\u0435\u043C\u044B:"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: currentLevel,
      onChange: (e) => setCurrentLevel(e.target.value),
      className: "w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
    },
    /* @__PURE__ */ React.createElement("option", { value: "L0" }, "L0 - \u0411\u0430\u0437\u043E\u0432\u044B\u0439 (Pentium I \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C)"),
    /* @__PURE__ */ React.createElement("option", { value: "L1" }, "L1 - \u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u043D\u044B\u0439 (\u041E\u043D\u043B\u0430\u0439\u043D \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F)"),
    /* @__PURE__ */ React.createElement("option", { value: "L2" }, "L2 - \u041F\u0440\u043E\u0434\u0432\u0438\u043D\u0443\u0442\u044B\u0439 (FMP \u0430\u043B\u0433\u043E\u0440\u0438\u0442\u043C\u044B)"),
    /* @__PURE__ */ React.createElement("option", { value: "L3" }, "L3 - \u042D\u043A\u0441\u043F\u0435\u0440\u0442\u043D\u044B\u0439 (\u041F\u043E\u043B\u043D\u0430\u044F AI \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F)")
  )), /* @__PURE__ */ React.createElement("div", { className: "mb-4" }, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442:"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: activeComponent,
      onChange: (e) => setActiveComponent(e.target.value),
      className: "w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
    },
    /* @__PURE__ */ React.createElement("option", { value: "knowledge-processor" }, "Knowledge Processor"),
    /* @__PURE__ */ React.createElement("option", { value: "universal-interface" }, "Universal Interface"),
    /* @__PURE__ */ React.createElement("option", { value: "fmp-engine" }, "FMP Engine"),
    /* @__PURE__ */ React.createElement("option", { value: "llm-core" }, "LLM Core")
  )), /* @__PURE__ */ React.createElement("div", { className: "mb-4" }, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u0414\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F:"), /* @__PURE__ */ React.createElement("div", { className: "flex space-x-2" }, ["L0", "L1", "L2", "L3"].map((level) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: level,
      onClick: () => setDetoxLevel(level),
      className: `px-3 py-1 rounded text-sm font-medium transition-colors ${detoxLevel === level ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-700 hover:bg-gray-300"}`
    },
    level
  )))), /* @__PURE__ */ React.createElement("div", { className: "mb-4 p-3 bg-gray-50 rounded-lg" }, /* @__PURE__ */ React.createElement("h3", { className: "text-sm font-medium text-gray-700 mb-2" }, "\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F:"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-600 space-y-1" }, /* @__PURE__ */ React.createElement("div", null, "\u{1F30D} \u042F\u0437\u044B\u043A: ", userContext.language.toUpperCase()), /* @__PURE__ */ React.createElement("div", null, "\u{1F4BB} \u0423\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E: ", userContext.device), /* @__PURE__ */ React.createElement("div", null, "\u{1F3DB}\uFE0F \u041A\u0443\u043B\u044C\u0442\u0443\u0440\u0430: ", userContext.culturalContext))))), /* @__PURE__ */ React.createElement("div", { className: "lg:col-span-2" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold mb-4 flex items-center" }, /* @__PURE__ */ React.createElement("span", { className: "mr-2" }, "\u{1F504}"), "\u0421\u0442\u0430\u0442\u0443\u0441 \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u0438 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043E\u0432"), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-medium mb-3" }, "\u2705 \u0413\u043E\u0442\u043E\u0432\u044B\u0435 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u044B:"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3" }, integratedFeatures.map((feature, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex items-center p-3 bg-green-50 border border-green-200 rounded-lg" }, /* @__PURE__ */ React.createElement("span", { className: "mr-2" }, "\u2705"), /* @__PURE__ */ React.createElement("span", { className: "text-green-800 font-medium" }, feature))))), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-medium mb-3" }, "\u26A1 \u042D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u044B\u0435 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0438:"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, emergentCapabilities.map((capability, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex items-center p-3 bg-purple-50 border border-purple-200 rounded-lg" }, /* @__PURE__ */ React.createElement("span", { className: "mr-2" }, "\u26A1"), /* @__PURE__ */ React.createElement("span", { className: "text-purple-800 font-medium" }, capability))))), /* @__PURE__ */ React.createElement("div", { className: "mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-medium mb-3 text-blue-800" }, "\u{1F9EC} \u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u044F FMP \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438:"), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-blue-700 space-y-2" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0430\u043C\u043E-\u043F\u043E\u0434\u043E\u0431\u043D\u043E\u0441\u0442\u044C:"), " \u041E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0435 \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u044B \u043D\u0430 \u0432\u0441\u0435\u0445 \u0443\u0440\u043E\u0432\u043D\u044F\u0445 L0-L", currentLevel.substring(1)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "\u0420\u0435\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u0430\u044F co-\u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F:"), " \u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0430\u0434\u0430\u043F\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u043A \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044E: ", userContext.culturalContext), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "\u042D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u0430\u044F \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F:"), " ", emergentCapabilities.length, " \u043D\u043E\u0432\u044B\u0445 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0435\u0439 \u0438\u0437 ", integratedFeatures.length, " \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043E\u0432"))), /* @__PURE__ */ React.createElement("div", { className: "p-4 bg-gray-50 border border-gray-200 rounded-lg" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-medium mb-3" }, "\u{1F9EA} \u0422\u0435\u0441\u0442\u043E\u0432\u0430\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u0438:"), /* @__PURE__ */ React.createElement("div", { className: "text-center py-8 text-gray-500" }, /* @__PURE__ */ React.createElement("p", null, "\u041A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442 \u0433\u043E\u0442\u043E\u0432 \u043A \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u0438 \u0441 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C\u0438 TERRA LLM \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u043C\u0438"), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u0443\u0440\u043E\u0432\u0435\u043D\u044C: ", /* @__PURE__ */ React.createElement("strong", null, currentLevel), " | \u0414\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F: ", /* @__PURE__ */ React.createElement("strong", null, detoxLevel))))))), /* @__PURE__ */ React.createElement("footer", { className: "mt-8 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "inline-flex items-center justify-center space-x-4 p-4 bg-white rounded-xl shadow-lg" }, /* @__PURE__ */ React.createElement("div", { className: "w-16 h-16 bg-gray-200 border-2 border-gray-300 rounded flex items-center justify-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-center" }, /* @__PURE__ */ React.createElement("div", null, "QR"), /* @__PURE__ */ React.createElement("div", null, "TERRA"))), /* @__PURE__ */ React.createElement("div", { className: "text-left" }, /* @__PURE__ */ React.createElement("p", { className: "text-sm font-medium text-gray-800" }, "TERRA LLM Integration Engine"), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-600" }, "\u041D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u043E\u0432 \u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u043E\u0439 \u041C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0438"), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-500 mt-1" }, '"\u042D\u0442\u043E\u0442 \u043F\u0440\u043E\u0435\u043A\u0442 - \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u044B \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430 \u0438 \u0418\u0418 \u0432\u043E \u0431\u043B\u0430\u0433\u043E \u0431\u0443\u0434\u0443\u0449\u0435\u0433\u043E \u043F\u043B\u0430\u043D\u0435\u0442\u044B"')))));
};
var stdin_default = TerraLLMIntegrationEngine;
export {
  stdin_default as default
};
