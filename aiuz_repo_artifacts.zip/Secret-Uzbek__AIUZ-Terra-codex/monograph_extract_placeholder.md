# Monograph Extracts: Secret-Uzbek/AIUZ-Terra-codex

Automated extraction: partial. Full chapter extraction requires fetching raw text files from the repository (ZIP or raw links).

If the repo contains monographs (FMP-monograph or Theory-of-fractal...), request direct ZIP download to extract full text.

