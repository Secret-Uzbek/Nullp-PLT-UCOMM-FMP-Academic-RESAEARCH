TCPP v1.0 — Publish Ready Full Package
DOI: 10.5281/zenodo.17425678
Author: Abdurashid Abdukarimov (ORCID: 0009-0000-6394-4912)
License: CC-BY-4.0
Contents:
- TCPP_v1.0_release.zip (main artifact, included if available)
- terra_proof_ledger_TERRA-PROOF-2025-001.json
- zenodo_upload.json
- github_release_manifest.json
- DOI_metadata.txt (human-readable record)
- index.html (release page)
- README_publish.md (instructions)
- checksums.sha256
