# Case Studies
- Education (AI in STEM learning) — reuse of FEUs across courses.
- Smart cities (digital twins) — fractalization of sensor models.
- Uzbek-Mining — domain ontology and data modules.
