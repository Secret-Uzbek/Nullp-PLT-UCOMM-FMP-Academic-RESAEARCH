# Formalism of FMP (Markdown draft)
This chapter introduces definitions and notation for Fractal Epistemic Units (FEU), composition operators, and canonical transforms used in NULLO PLT.
- Definition: FEU = (M, S, R)
- Composition: FEU_a ∘ FEU_b = FEU_c with merge rules
- Proof sketches and examples
