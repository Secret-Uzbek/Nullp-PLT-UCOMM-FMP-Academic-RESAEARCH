# AIUZ — Reworked Release (NULLO PLT UCOMM FMP logic)
Generated: 2025-10-29 11:10:30 UTC

Сборка содержит переработанные материалы, подготовленные в соответствии с логикой:
**NULLO PLT UCOMM FMP** — Nullo Platform (PLT), UCOMM (Unified Communications/Community protocols), Fractal Metascience Paradigm (FMP).

Содержимое:
- articles/ — LaTeX и Markdown исходники двух статей (FMP + Nullo instantiation)
- monograph/ — LaTeX-проект монографии (главы в tex/markdown)
- thesis/ — PhD draft (tex)
- code/ — React component(s), OpenAPI spec, Dockerfile, GitHub Actions workflow
- publish_checklist.md — чеклист подготовки к публикации
- LICENSE.txt — default MIT (изменяем по необходимости)

Замечание: PDF-файлы не компилированы в этом окружении; включены `.tex` и `.md` исходники. Для получения PDF выполните `pdflatex` или используйте `latexmk` в вашей сборочной среде.
