import React from 'react';

export default function FractalNodePreview({node, onOpen}){
  return (
    <div className="p-4 rounded-xl shadow-sm hover:shadow-md transition">
      <h4 className="font-semibold">{node.title}</h4>
      <p className="text-sm">{node.excerpt}</p>
      <div className="mt-2 text-xs opacity-80">{(node.tags||[]).join(' • ')}</div>
      <button onClick={()=>onOpen(node)} className="mt-3 px-3 py-1 rounded bg-gray-100">Open</button>
    </div>
  )
}
