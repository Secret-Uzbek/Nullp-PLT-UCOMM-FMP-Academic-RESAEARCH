React sample: place FractalNodePreview.jsx into a create-react-app project under src/components and import it.
