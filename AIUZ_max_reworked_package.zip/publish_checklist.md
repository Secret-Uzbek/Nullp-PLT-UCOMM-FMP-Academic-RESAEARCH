# Publish Checklist (AIUZ NULLO PLT UCOMM FMP)
- [ ] Bibliographic verification: add 3+ peer-reviewed sources per major claim.
- [ ] Remove or redact any secrets, private keys, credentials from code.
- [ ] License: confirm MIT or preferred license for each artifact.
- [ ] Authorship: list contributors and ORCID ids.
- [ ] Data availability: deposit datasets (Zenodo) and include DOIs.
- [ ] Reproducibility: include Dockerfile and instructions for build.
- [ ] Ethical clearance: include IRB / ethics statements where human subjects are involved.
- [ ] Compilation: produce PDF versions from LaTeX using `latexmk` or CI.
- [ ] Final review by domain leads (education, mining, smart cities).
