# 📜 Terra Public License v1.0

**AIUZ Terra Ecosystem — Open Documentation License**

This license applies to all documentation, protocols, semantic archives, and code artifacts within the AIUZ Terra Codex Archive v1.0, unless otherwise specified.

[...] Signed: Abdurashid Abdukarimov