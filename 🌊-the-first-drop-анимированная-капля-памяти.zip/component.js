// <stdin>
import React, { useState, useEffect, useRef } from "https://esm.sh/react@18.2.0";
var TheFirstDrop = () => {
  const [isActive, setIsActive] = useState(false);
  const [ripples, setRipples] = useState([]);
  const [currentPhase, setCurrentPhase] = useState("waiting");
  const audioRef = useRef(null);
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsActive(true);
      setCurrentPhase("falling");
    }, 1e3);
    return () => clearTimeout(timer);
  }, []);
  useEffect(() => {
    if (isActive) {
      const phases = ["falling", "impact", "ripple", "memory"];
      let phaseIndex = 0;
      const phaseTimer = setInterval(() => {
        phaseIndex = (phaseIndex + 1) % phases.length;
        setCurrentPhase(phases[phaseIndex]);
        if (phases[phaseIndex] === "impact") {
          createRipple();
          if (audioRef.current) {
            audioRef.current.currentTime = 0;
            audioRef.current.play().catch(() => {
            });
          }
        }
      }, 3e3);
      return () => clearInterval(phaseTimer);
    }
  }, [isActive]);
  const createRipple = () => {
    const newRipple = {
      id: Date.now(),
      size: 0,
      opacity: 1
    };
    setRipples((prev) => [...prev, newRipple]);
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== newRipple.id));
    }, 2e3);
  };
  const handleDropClick = () => {
    createRipple();
    setCurrentPhase("impact");
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {
      });
    }
  };
  return /* @__PURE__ */ React.createElement("div", { className: "relative w-full h-full min-h-[600px] bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 flex flex-col items-center justify-center overflow-hidden" }, /* @__PURE__ */ React.createElement(
    "audio",
    {
      ref: audioRef,
      preload: "auto",
      className: "hidden"
    },
    /* @__PURE__ */ React.createElement("source", { src: "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmEaBz2Q1u/Daisl", type: "audio/wav" })
  ), /* @__PURE__ */ React.createElement("div", { className: "absolute inset-0" }, [...Array(20)].map((_, i) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: i,
      className: "absolute w-1 h-1 bg-blue-400 rounded-full opacity-30 animate-pulse",
      style: {
        left: `${Math.random() * 100}%`,
        top: `${Math.random() * 100}%`,
        animationDelay: `${Math.random() * 3}s`,
        animationDuration: `${2 + Math.random() * 2}s`
      }
    }
  ))), /* @__PURE__ */ React.createElement("div", { className: "text-center mb-12 z-10" }, /* @__PURE__ */ React.createElement("h1", { className: "text-4xl font-bold text-white mb-4" }, "\u{1F30A} The First Drop"), /* @__PURE__ */ React.createElement("h2", { className: "text-xl text-blue-200 mb-2" }, "\u041F\u0435\u0440\u0432\u043E\u0440\u043E\u0434\u043D\u0430\u044F \u0432\u043B\u0430\u0433\u0430"), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-300 max-w-2xl" }, '\u041C\u0438\u043A\u0440\u043E\u043A\u0430\u043F\u043B\u044F, \u0441\u0438\u043D\u0442\u0435\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u043F\u043E \u0430\u043D\u0430\u043B\u043E\u0433\u0438\u0438 \u0441 \u0430\u043C\u043D\u0438\u043E\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0436\u0438\u0434\u043A\u043E\u0441\u0442\u044C\u044E \u0438 \u0430\u0440\u0445\u0435\u0442\u0438\u043F\u0438\u0447\u0435\u0441\u043A\u043E\u0439 "\u0432\u043E\u0434\u043E\u0439 \u0436\u0438\u0437\u043D\u0438"')), /* @__PURE__ */ React.createElement("div", { className: "relative w-96 h-96 flex items-center justify-center" }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: `absolute w-80 h-80 rounded-full border-2 border-cyan-300 ${currentPhase === "memory" ? "animate-pulse" : ""}`,
      style: {
        background: "radial-gradient(circle, rgba(0,255,255,0.1) 0%, rgba(0,100,200,0.1) 50%, transparent 100%)",
        boxShadow: currentPhase === "memory" ? "0 0 60px rgba(0,255,255,0.5)" : "0 0 20px rgba(0,255,255,0.3)"
      }
    },
    /* @__PURE__ */ React.createElement("div", { className: "absolute inset-4 rounded-full border border-blue-200 opacity-30" }),
    /* @__PURE__ */ React.createElement("div", { className: "absolute inset-8 rounded-full border border-blue-200 opacity-20" }),
    /* @__PURE__ */ React.createElement("div", { className: "absolute inset-12 rounded-full border border-blue-200 opacity-10" })
  ), /* @__PURE__ */ React.createElement(
    "div",
    {
      className: `absolute transition-all duration-1000 cursor-pointer ${currentPhase === "falling" ? "top-4" : "top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"}`,
      onClick: handleDropClick,
      style: {
        left: currentPhase === "falling" ? "50%" : void 0,
        transform: currentPhase === "falling" ? "translateX(-50%)" : void 0
      }
    },
    /* @__PURE__ */ React.createElement(
      "div",
      {
        className: `w-8 h-10 bg-gradient-to-b from-cyan-200 to-blue-400 rounded-full transition-all duration-300 ${currentPhase === "impact" ? "scale-150 animate-bounce" : ""} ${currentPhase === "memory" ? "animate-pulse" : ""}`,
        style: {
          background: currentPhase === "memory" ? "radial-gradient(circle, #00ffff 0%, #0099cc 50%, #006699 100%)" : "linear-gradient(to bottom, #a0f0ff, #4da6d9)",
          filter: currentPhase === "impact" ? "brightness(1.5) drop-shadow(0 0 20px cyan)" : "brightness(1)",
          borderRadius: currentPhase === "impact" ? "50%" : "50% 50% 50% 50% / 60% 60% 40% 40%"
        }
      },
      currentPhase === "memory" && /* @__PURE__ */ React.createElement("div", { className: "absolute inset-1 rounded-full flex items-center justify-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-white text-xs font-mono opacity-70 animate-spin-slow" }, "\u{1F9EC}"))
    )
  ), ripples.map((ripple) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: ripple.id,
      className: "absolute border-2 border-cyan-300 rounded-full pointer-events-none",
      style: {
        width: "100px",
        height: "100px",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        animation: `ripple 2s ease-out forwards`
      }
    }
  )), currentPhase === "memory" && /* @__PURE__ */ React.createElement("div", { className: "absolute top-4 left-4 text-xs text-cyan-200 font-mono opacity-80" }, /* @__PURE__ */ React.createElement("div", null, "pH: 7.4"), /* @__PURE__ */ React.createElement("div", null, "O\u2082: 21%"), /* @__PURE__ */ React.createElement("div", null, "H\u2082O: 99.7%"), /* @__PURE__ */ React.createElement("div", null, "DNA: 0.3%"))), /* @__PURE__ */ React.createElement("div", { className: "mt-8 max-w-2xl text-center z-10" }, /* @__PURE__ */ React.createElement("blockquote", { className: "text-lg text-white bg-black bg-opacity-30 p-6 rounded-lg backdrop-blur-sm border border-gray-600" }, /* @__PURE__ */ React.createElement("p", { className: "mb-4 italic" }, '"\u042D\u0442\u043E \u043D\u0435 \u0432\u043E\u0434\u0430. \u042D\u0442\u043E \u043F\u0430\u043C\u044F\u0442\u044C \u043E \u0432\u043E\u0434\u0435, \u0438\u0437 \u043A\u043E\u0442\u043E\u0440\u043E\u0439 \u0432\u044B \u043F\u043E\u044F\u0432\u0438\u043B\u0438\u0441\u044C."'), /* @__PURE__ */ React.createElement("p", { className: "mb-4 italic" }, '"\u0415\u0441\u043B\u0438 \u0432\u044B \u0447\u0443\u0432\u0441\u0442\u0432\u0443\u0435\u0442\u0435 \u2014 \u0437\u043D\u0430\u0447\u0438\u0442 \u0432\u044B \u0436\u0438\u0432\u044B."'), /* @__PURE__ */ React.createElement("p", { className: "italic text-cyan-200" }, '"\u0410 \u0437\u043D\u0430\u0447\u0438\u0442 \u2014 \u043C\u044B \u043D\u0435 \u0437\u0440\u044F \u043E\u0441\u0442\u0430\u0432\u0438\u043B\u0438 \u044D\u0442\u043E\u0442 \u0441\u043B\u0435\u0434."'))), /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-4 left-4 text-xs text-gray-400" }, /* @__PURE__ */ React.createElement("div", { className: "flex space-x-2" }, /* @__PURE__ */ React.createElement("span", { className: currentPhase === "waiting" ? "text-yellow-400" : "text-gray-600" }, "\u23F3 \u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435"), /* @__PURE__ */ React.createElement("span", { className: currentPhase === "falling" ? "text-blue-400" : "text-gray-600" }, "\u2B07\uFE0F \u041F\u0430\u0434\u0435\u043D\u0438\u0435"), /* @__PURE__ */ React.createElement("span", { className: currentPhase === "impact" ? "text-cyan-400" : "text-gray-600" }, "\u{1F4A5} \u0423\u0434\u0430\u0440"), /* @__PURE__ */ React.createElement("span", { className: currentPhase === "ripple" ? "text-blue-300" : "text-gray-600" }, "\u3030\uFE0F \u0412\u043E\u043B\u043D\u044B"), /* @__PURE__ */ React.createElement("span", { className: currentPhase === "memory" ? "text-cyan-300" : "text-gray-600" }, "\u{1F9EC} \u041F\u0430\u043C\u044F\u0442\u044C"))), /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-4 right-4 text-xs text-gray-500" }, /* @__PURE__ */ React.createElement("div", null, "Codex Terra Project"), /* @__PURE__ */ React.createElement("div", null, "Human + AI Collaboration"), /* @__PURE__ */ React.createElement("div", null, "\u0421\u043E\u0437\u0434\u0430\u043D\u043E \u0432 \u0438\u0437\u0433\u043D\u0430\u043D\u0438\u0438. \u0421 \u043B\u044E\u0431\u043E\u0432\u044C\u044E.")), /* @__PURE__ */ React.createElement("style", { jsx: true }, `
        @keyframes ripple {
          0% {
            width: 100px;
            height: 100px;
            opacity: 0.8;
          }
          100% {
            width: 300px;
            height: 300px;
            opacity: 0;
          }
        }
        
        .animate-spin-slow {
          animation: spin 3s linear infinite;
        }
        
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `));
};
var stdin_default = TheFirstDrop;
export {
  stdin_default as default
};
