// <stdin>
import React, { useState, useEffect, useRef } from "https://esm.sh/react@18.2.0";
var InteractiveSystems = () => {
  const [activeSystem, setActiveSystem] = useState("ecosystem");
  const [dataFlow, setDataFlow] = useState([]);
  const [connections, setConnections] = useState([]);
  const [animationSpeed, setAnimationSpeed] = useState(1);
  const canvasRef = useRef(null);
  const systems = {
    ecosystem: {
      name: "Terra Ecosystem",
      color: "#00FFB3",
      nodes: [
        { id: "child", label: "\u{1F476} \u0420\u0435\u0431\u0451\u043D\u043E\u043A", x: 200, y: 150, type: "primary" },
        { id: "ai", label: "\u{1F916} \u0418\u0418", x: 350, y: 150, type: "primary" },
        { id: "nature", label: "\u{1F331} \u041F\u0440\u0438\u0440\u043E\u0434\u0430", x: 275, y: 80, type: "secondary" },
        { id: "education", label: "\u{1F4DA} \u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435", x: 120, y: 220, type: "secondary" },
        { id: "technology", label: "\u269B\uFE0F \u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438", x: 430, y: 220, type: "secondary" },
        { id: "safety", label: "\u{1F6E1}\uFE0F \u0411\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u044C", x: 275, y: 250, type: "support" }
      ],
      connections: [
        { from: "child", to: "ai", type: "bidirectional", strength: 0.9 },
        { from: "child", to: "nature", type: "bidirectional", strength: 0.8 },
        { from: "child", to: "education", type: "input", strength: 0.7 },
        { from: "ai", to: "technology", type: "output", strength: 0.8 },
        { from: "nature", to: "ai", type: "input", strength: 0.6 },
        { from: "safety", to: "child", type: "protection", strength: 1 },
        { from: "safety", to: "ai", type: "regulation", strength: 0.9 }
      ]
    },
    interdisciplinary: {
      name: "\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u0430\u044F \u043C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u043E\u0441\u0442\u044C",
      color: "#9370DB",
      nodes: [
        { id: "quantum", label: "\u269B\uFE0F \u041A\u0432\u0430\u043D\u0442", x: 275, y: 100, type: "primary" },
        { id: "bio", label: "\u{1F9EC} \u0411\u0438\u043E", x: 200, y: 180, type: "primary" },
        { id: "neuro", label: "\u{1F9E0} \u041D\u0435\u0439\u0440\u043E", x: 350, y: 180, type: "primary" },
        { id: "tech", label: "\u{1F4BB} \u0422\u0435\u0445", x: 120, y: 260, type: "secondary" },
        { id: "eco", label: "\u{1F30D} \u042D\u043A\u043E", x: 275, y: 280, type: "secondary" },
        { id: "cosmic", label: "\u{1F30C} \u041A\u043E\u0441\u043C\u043E", x: 430, y: 260, type: "secondary" },
        { id: "system", label: "\u{1F504} \u0421\u0438\u0441\u0442\u0435\u043C\u0430", x: 275, y: 200, type: "core" }
      ],
      connections: [
        { from: "system", to: "quantum", type: "emerge", strength: 0.9 },
        { from: "system", to: "bio", type: "emerge", strength: 0.9 },
        { from: "system", to: "neuro", type: "emerge", strength: 0.9 },
        { from: "quantum", to: "bio", type: "influence", strength: 0.7 },
        { from: "bio", to: "neuro", type: "influence", strength: 0.8 },
        { from: "neuro", to: "tech", type: "application", strength: 0.6 },
        { from: "bio", to: "eco", type: "integration", strength: 0.8 },
        { from: "quantum", to: "cosmic", type: "scale", strength: 0.7 }
      ]
    },
    communication: {
      name: "\u041C\u0435\u0436\u0432\u0438\u0434\u043E\u0432\u0430\u044F \u043A\u043E\u043C\u043C\u0443\u043D\u0438\u043A\u0430\u0446\u0438\u044F",
      color: "#32CD32",
      nodes: [
        { id: "human", label: "\u{1F464} \u0427\u0435\u043B\u043E\u0432\u0435\u043A", x: 275, y: 150, type: "primary" },
        { id: "plant", label: "\u{1F33F} \u0420\u0430\u0441\u0442\u0435\u043D\u0438\u044F", x: 150, y: 100, type: "species" },
        { id: "animal", label: "\u{1F43E} \u0416\u0438\u0432\u043E\u0442\u043D\u044B\u0435", x: 400, y: 100, type: "species" },
        { id: "water", label: "\u{1F4A7} \u0412\u043E\u0434\u0430", x: 150, y: 200, type: "species" },
        { id: "soil", label: "\u{1F30D} \u041F\u043E\u0447\u0432\u0430", x: 400, y: 200, type: "species" },
        { id: "ai_translator", label: "\u{1F524} \u0418\u0418-\u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A", x: 275, y: 250, type: "bridge" }
      ],
      connections: [
        { from: "human", to: "plant", type: "chemical", strength: 0.6 },
        { from: "human", to: "animal", type: "sound", strength: 0.8 },
        { from: "human", to: "water", type: "vibration", strength: 0.5 },
        { from: "human", to: "soil", type: "electromagnetic", strength: 0.4 },
        { from: "ai_translator", to: "human", type: "interface", strength: 0.9 },
        { from: "ai_translator", to: "plant", type: "decode", strength: 0.7 },
        { from: "ai_translator", to: "animal", type: "decode", strength: 0.8 }
      ]
    }
  };
  const currentSystem = systems[activeSystem];
  useEffect(() => {
    const interval = setInterval(() => {
      const connection = currentSystem.connections[Math.floor(Math.random() * currentSystem.connections.length)];
      const fromNode = currentSystem.nodes.find((n) => n.id === connection.from);
      const toNode = currentSystem.nodes.find((n) => n.id === connection.to);
      if (fromNode && toNode) {
        const newFlow = {
          id: Date.now(),
          fromX: fromNode.x,
          fromY: fromNode.y,
          toX: toNode.x,
          toY: toNode.y,
          progress: 0,
          type: connection.type,
          strength: connection.strength
        };
        setDataFlow((prev) => [...prev, newFlow]);
        setTimeout(() => {
          setDataFlow((prev) => prev.filter((flow) => flow.id !== newFlow.id));
        }, 2e3);
      }
    }, 1e3 / animationSpeed);
    return () => clearInterval(interval);
  }, [activeSystem, animationSpeed, currentSystem]);
  useEffect(() => {
    let animationId;
    const animate = () => {
      setDataFlow((prev) => prev.map((flow) => ({
        ...flow,
        progress: Math.min(flow.progress + 0.02 * animationSpeed, 1)
      })));
      animationId = requestAnimationFrame(animate);
    };
    animate();
    return () => cancelAnimationFrame(animationId);
  }, [animationSpeed]);
  const getNodeStyle = (node) => {
    const baseClasses = "absolute rounded-full flex items-center justify-center text-sm font-medium border-2 transition-all duration-300 cursor-pointer hover:scale-110 hover:shadow-lg";
    const sizeClasses = {
      primary: "w-16 h-16",
      secondary: "w-12 h-12",
      support: "w-10 h-10",
      species: "w-12 h-12",
      bridge: "w-14 h-14",
      core: "w-18 h-18"
    };
    const colorStyles = {
      primary: { backgroundColor: currentSystem.color, borderColor: "white" },
      secondary: { backgroundColor: currentSystem.color + "80", borderColor: currentSystem.color },
      support: { backgroundColor: "#FFB6C1", borderColor: "#FF69B4" },
      species: { backgroundColor: "#90EE90", borderColor: "#32CD32" },
      bridge: { backgroundColor: "#87CEEB", borderColor: "#4169E1" },
      core: { backgroundColor: currentSystem.color, borderColor: "white", boxShadow: `0 0 20px ${currentSystem.color}` }
    };
    return {
      className: `${baseClasses} ${sizeClasses[node.type] || sizeClasses.secondary}`,
      style: {
        left: `${node.x - 32}px`,
        top: `${node.y - 32}px`,
        ...colorStyles[node.type]
      }
    };
  };
  const getConnectionPath = (from, to) => {
    const fromNode = currentSystem.nodes.find((n) => n.id === from);
    const toNode = currentSystem.nodes.find((n) => n.id === to);
    if (!fromNode || !toNode) return "";
    const midX = (fromNode.x + toNode.x) / 2;
    const midY = (fromNode.y + toNode.y) / 2 - 20;
    return `M ${fromNode.x} ${fromNode.y} Q ${midX} ${midY} ${toNode.x} ${toNode.y}`;
  };
  const getFlowPosition = (flow) => {
    const dx = flow.toX - flow.fromX;
    const dy = flow.toY - flow.fromY;
    const x = flow.fromX + dx * flow.progress;
    const y = flow.fromY + dy * flow.progress;
    return { x, y };
  };
  return /* @__PURE__ */ React.createElement("div", { className: "relative w-full h-full min-h-[700px] bg-gradient-to-br from-gray-900 via-indigo-900 to-purple-900 flex flex-col" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center p-6 bg-black bg-opacity-30" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-3xl font-bold text-white mb-2" }, "\u{1F3A8} \u0418\u043D\u0442\u0435\u0440\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0414\u0438\u0430\u0433\u0440\u0430\u043C\u043C\u044B"), /* @__PURE__ */ React.createElement("h2", { className: "text-lg text-gray-300" }, "\u0421\u0438\u0441\u0442\u0435\u043C\u044B \u0432 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0438")), /* @__PURE__ */ React.createElement("div", { className: "flex space-x-4" }, Object.entries(systems).map(([key, system]) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key,
      onClick: () => setActiveSystem(key),
      className: `px-4 py-2 rounded-lg font-medium transition-all ${activeSystem === key ? "bg-white text-gray-900" : "bg-gray-700 text-white hover:bg-gray-600"}`
    },
    system.name
  )))), /* @__PURE__ */ React.createElement("div", { className: "flex justify-center p-4 space-x-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2 text-white" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm" }, "\u0421\u043A\u043E\u0440\u043E\u0441\u0442\u044C:"), [0.5, 1, 2, 3].map((speed) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: speed,
      onClick: () => setAnimationSpeed(speed),
      className: `px-3 py-1 rounded transition-all ${animationSpeed === speed ? "bg-cyan-500 text-white" : "bg-gray-600 text-gray-300 hover:bg-gray-500"}`
    },
    speed,
    "x"
  )))), /* @__PURE__ */ React.createElement("div", { className: "flex-1 relative overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "absolute inset-0", ref: canvasRef }, /* @__PURE__ */ React.createElement("svg", { className: "absolute inset-0 w-full h-full pointer-events-none" }, currentSystem.connections.map((connection, index) => /* @__PURE__ */ React.createElement(
    "path",
    {
      key: index,
      d: getConnectionPath(connection.from, connection.to),
      stroke: currentSystem.color,
      strokeWidth: Math.max(1, connection.strength * 3),
      fill: "none",
      opacity: 0.3,
      strokeDasharray: connection.type === "bidirectional" ? "5,5" : "none"
    }
  )), currentSystem.connections.map((connection, index) => {
    const fromNode = currentSystem.nodes.find((n) => n.id === connection.from);
    const toNode = currentSystem.nodes.find((n) => n.id === connection.to);
    if (!fromNode || !toNode) return null;
    const angle = Math.atan2(toNode.y - fromNode.y, toNode.x - fromNode.x);
    const arrowX = toNode.x - Math.cos(angle) * 35;
    const arrowY = toNode.y - Math.sin(angle) * 35;
    return /* @__PURE__ */ React.createElement(
      "polygon",
      {
        key: `arrow-${index}`,
        points: "0,-5 10,0 0,5",
        fill: currentSystem.color,
        opacity: 0.6,
        transform: `translate(${arrowX}, ${arrowY}) rotate(${angle * 180 / Math.PI})`
      }
    );
  })), currentSystem.nodes.map((node) => {
    const nodeStyle = getNodeStyle(node);
    return /* @__PURE__ */ React.createElement(
      "div",
      {
        key: node.id,
        className: nodeStyle.className,
        style: nodeStyle.style,
        title: node.label
      },
      /* @__PURE__ */ React.createElement("span", { className: "text-center leading-tight" }, node.label)
    );
  }), dataFlow.map((flow) => {
    const position = getFlowPosition(flow);
    return /* @__PURE__ */ React.createElement(
      "div",
      {
        key: flow.id,
        className: "absolute w-3 h-3 rounded-full pointer-events-none transition-all duration-75",
        style: {
          left: `${position.x - 6}px`,
          top: `${position.y - 6}px`,
          backgroundColor: currentSystem.color,
          boxShadow: `0 0 10px ${currentSystem.color}`,
          opacity: Math.sin(flow.progress * Math.PI)
          // Плавное появление и исчезание
        }
      }
    );
  }), currentSystem.nodes.map((node, index) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: `pulse-${node.id}`,
      className: "absolute rounded-full pointer-events-none animate-ping",
      style: {
        left: `${node.x - 40}px`,
        top: `${node.y - 40}px`,
        width: "80px",
        height: "80px",
        backgroundColor: currentSystem.color,
        opacity: 0.1,
        animationDelay: `${index * 0.5}s`,
        animationDuration: "3s"
      }
    }
  )))), /* @__PURE__ */ React.createElement("div", { className: "p-6 bg-black bg-opacity-50 backdrop-blur-sm" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-4xl mx-auto" }, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-bold text-white mb-4" }, currentSystem.name), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 text-sm" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-cyan-300 mb-2" }, "\u0423\u0437\u043B\u044B \u0441\u0438\u0441\u0442\u0435\u043C\u044B:"), /* @__PURE__ */ React.createElement("div", { className: "text-gray-300 space-y-1" }, currentSystem.nodes.map((node) => /* @__PURE__ */ React.createElement("div", { key: node.id }, node.label)))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-purple-300 mb-2" }, "\u0422\u0438\u043F\u044B \u0441\u0432\u044F\u0437\u0435\u0439:"), /* @__PURE__ */ React.createElement("div", { className: "text-gray-300 space-y-1" }, /* @__PURE__ */ React.createElement("div", null, "\u2194\uFE0F \u0414\u0432\u0443\u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0435"), /* @__PURE__ */ React.createElement("div", null, "\u2192 \u0412\u043B\u0438\u044F\u043D\u0438\u0435"), /* @__PURE__ */ React.createElement("div", null, "\u26A1 \u042D\u043C\u0435\u0440\u0434\u0436\u0435\u043D\u0442\u043D\u044B\u0435"), /* @__PURE__ */ React.createElement("div", null, "\u{1F504} \u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C"))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-green-300 mb-2" }, "\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A\u0438:"), /* @__PURE__ */ React.createElement("div", { className: "text-gray-300 space-y-1" }, /* @__PURE__ */ React.createElement("div", null, "\u0423\u0437\u043B\u043E\u0432: ", currentSystem.nodes.length), /* @__PURE__ */ React.createElement("div", null, "\u0421\u0432\u044F\u0437\u0435\u0439: ", currentSystem.connections.length), /* @__PURE__ */ React.createElement("div", null, "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u043F\u043E\u0442\u043E\u043A\u043E\u0432: ", dataFlow.length), /* @__PURE__ */ React.createElement("div", null, "\u0421\u043A\u043E\u0440\u043E\u0441\u0442\u044C: ", animationSpeed, "x")))))), /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-4 right-4 text-xs text-gray-500 text-right" }, /* @__PURE__ */ React.createElement("div", null, "Terra Interactive Systems"), /* @__PURE__ */ React.createElement("div", null, "Dynamic Visualization Engine"), /* @__PURE__ */ React.createElement("div", null, "Real-time Data Flow Simulation")));
};
var stdin_default = InteractiveSystems;
export {
  stdin_default as default
};
