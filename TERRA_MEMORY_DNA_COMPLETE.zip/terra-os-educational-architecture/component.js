// <stdin>
import React, { useState } from "https://esm.sh/react@18.2.0";
var { useStoredState } = hatch;
var TerraEducationalArchitecture = () => {
  const [activeComponent, setActiveComponent] = useState("SemanticKernel");
  const [simulationRunning, setSimulationRunning] = useState(false);
  const [dataFlow, setDataFlow] = useState([]);
  const [educationMetrics, setEducationMetrics] = useStoredState("education_metrics", {
    students_connected: 0,
    knowledge_units: 0,
    ar_sessions: 0,
    dao_votes: 0,
    ethical_validations: 0
  });
  const architectureComponents = {
    SemanticKernel: {
      title: "\u{1F9E0} Semantic Kernel",
      description: "\u042F\u0434\u0440\u043E \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u0441\u0435\u043C\u0430\u043D\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438",
      status: "active",
      color: "from-blue-500 to-indigo-600",
      connections: ["EducationModule"],
      features: [
        "Natural Language Processing",
        "Context Understanding",
        "Knowledge Extraction",
        "Semantic Indexing",
        "Multi-language Support"
      ]
    },
    EducationModule: {
      title: "\u{1F4DA} Education Module",
      description: "\u0426\u0435\u043D\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u0439 \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0440",
      status: "active",
      color: "from-green-500 to-emerald-600",
      connections: ["KnowledgeDB"],
      features: [
        "Adaptive Learning Paths",
        "Personalized Content",
        "Progress Tracking",
        "Interactive Lessons",
        "Assessment Engine"
      ]
    },
    KnowledgeDB: {
      title: "\u{1F4D6} Knowledge Database",
      description: "\u0413\u043B\u043E\u0431\u0430\u043B\u044C\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u0437\u043D\u0430\u043D\u0438\u0439 Terra \u0441 GlobalKnowledgeDB",
      status: "active",
      color: "from-purple-500 to-pink-600",
      connections: [],
      features: [
        "GlobalKnowledgeDB Query Engine",
        "Context-based Data Retrieval",
        "Dynamic Data Addition",
        "Auto-save Mechanism",
        "Distributed Storage",
        "Version Control",
        "Knowledge Graphs",
        "Content Validation",
        "Cross-References"
      ]
    },
    EthicalLayer: {
      title: "\u2696\uFE0F Ethical Layer",
      description: "\u0421\u043B\u043E\u0439 \u044D\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0432\u0430\u043B\u0438\u0434\u0430\u0446\u0438\u0438",
      status: "supporting",
      color: "from-amber-500 to-orange-600",
      connections: ["SemanticKernel"],
      features: [
        "Content Filtering",
        "Bias Detection",
        "Cultural Sensitivity",
        "Age Appropriateness",
        "Ethical Guidelines"
      ]
    },
    ARInterface: {
      title: "\u{1F97D} AR Interface",
      description: "\u0418\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441 \u0434\u043E\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u043E\u0439 \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438",
      status: "supporting",
      color: "from-cyan-500 to-blue-600",
      connections: ["EducationModule"],
      features: [
        "Immersive Learning",
        "3D Visualization",
        "Gesture Control",
        "Spatial Computing",
        "Mixed Reality"
      ]
    },
    DAOReputation: {
      title: "\u{1F3DB}\uFE0F DAO & Reputation",
      description: "\u0414\u0435\u0446\u0435\u043D\u0442\u0440\u0430\u043B\u0438\u0437\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0438 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F",
      status: "supporting",
      color: "from-red-500 to-pink-600",
      connections: ["KnowledgeDB"],
      features: [
        "Governance Voting",
        "Reputation Scoring",
        "Content Curation",
        "Community Moderation",
        "Token Economics"
      ]
    }
  };
  const runDataFlowSimulation = () => {
    if (simulationRunning) return;
    setSimulationRunning(true);
    const flow = [
      "SemanticKernel: \u041E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0437\u0430\u043F\u0440\u043E\u0441\u0430 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F...",
      "EthicalLayer: \u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u044D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043D\u043E\u0440\u043C...",
      "EducationModule: \u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u043A\u043E\u043D\u0442\u0435\u043D\u0442\u0430...",
      "ARInterface: \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u0438\u043C\u043C\u0435\u0440\u0441\u0438\u0432\u043D\u043E\u0433\u043E \u043E\u043F\u044B\u0442\u0430...",
      "KnowledgeDB: \u0418\u0437\u0432\u043B\u0435\u0447\u0435\u043D\u0438\u0435 \u0440\u0435\u043B\u0435\u0432\u0430\u043D\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438...",
      "DAOReputation: \u0412\u0430\u043B\u0438\u0434\u0430\u0446\u0438\u044F \u0441\u043E\u043E\u0431\u0449\u0435\u0441\u0442\u0432\u043E\u043C...",
      "EducationModule: \u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430 \u043A\u043E\u043D\u0442\u0435\u043D\u0442\u0430 \u0441\u0442\u0443\u0434\u0435\u043D\u0442\u0443..."
    ];
    setDataFlow([]);
    flow.forEach((step, index) => {
      setTimeout(() => {
        setDataFlow((prev) => [...prev, step]);
        setEducationMetrics((prev) => ({
          students_connected: prev.students_connected + Math.floor(Math.random() * 3),
          knowledge_units: prev.knowledge_units + Math.floor(Math.random() * 5),
          ar_sessions: prev.ar_sessions + Math.floor(Math.random() * 2),
          dao_votes: prev.dao_votes + Math.floor(Math.random() * 1),
          ethical_validations: prev.ethical_validations + 1
        }));
        if (index === flow.length - 1) {
          setTimeout(() => setSimulationRunning(false), 1e3);
        }
      }, index * 1e3);
    });
  };
  const simulateGlobalKnowledgeDB = () => {
    class GlobalKnowledgeDB {
      constructor() {
        this.data = JSON.parse(localStorage.getItem("terra_global_knowledge") || "{}");
      }
      query(context) {
        return this.data[context] || "No relevant information found.";
      }
      add_data(context, new_data) {
        this.data[context] = new_data;
        this.save_data();
      }
      save_data() {
        localStorage.setItem("terra_global_knowledge", JSON.stringify(this.data));
      }
      get_all_contexts() {
        return Object.keys(this.data);
      }
      get_data_size() {
        return Object.keys(this.data).length;
      }
    }
    const knowledgeDB = new GlobalKnowledgeDB();
    if (knowledgeDB.get_data_size() === 0) {
      knowledgeDB.add_data("machine_learning", "Advanced AI algorithms for pattern recognition and learning");
      knowledgeDB.add_data("blockchain", "Decentralized ledger technology for secure transactions");
      knowledgeDB.add_data("quantum_computing", "Computing using quantum-mechanical phenomena");
      knowledgeDB.add_data("neural_networks", "Computing systems inspired by biological neural networks");
      knowledgeDB.add_data("sustainability", "Meeting needs without compromising future generations");
    }
    return knowledgeDB;
  };
  const simulateDAO = () => {
    class VoteSystem {
      constructor() {
        this.votes = JSON.parse(localStorage.getItem("terra_dao_votes") || "{}");
        this.proposals = JSON.parse(localStorage.getItem("terra_dao_proposals") || "[]");
      }
      register_vote(proposal, user) {
        if (!this.votes[proposal.id]) {
          this.votes[proposal.id] = {};
        }
        this.votes[proposal.id][user] = {
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          vote: "approved"
        };
        this.save_votes();
      }
      is_valid(proposal) {
        const votes = this.votes[proposal.id] || {};
        const voteCount = Object.keys(votes).length;
        return voteCount >= proposal.min_votes_required;
      }
      get_proposal_votes(proposalId) {
        return Object.keys(this.votes[proposalId] || {}).length;
      }
      save_votes() {
        localStorage.setItem("terra_dao_votes", JSON.stringify(this.votes));
      }
      add_proposal(proposal) {
        proposal.id = "prop_" + Date.now();
        proposal.created_at = (/* @__PURE__ */ new Date()).toISOString();
        proposal.status = "active";
        this.proposals.push(proposal);
        localStorage.setItem("terra_dao_proposals", JSON.stringify(this.proposals));
        return proposal;
      }
      get_all_proposals() {
        return this.proposals;
      }
    }
    class ReputationSystem {
      constructor() {
        this.reputations = JSON.parse(localStorage.getItem("terra_user_reputations") || "{}");
      }
      check_user_eligibility(user) {
        const reputation = this.reputations[user] || 0;
        return reputation >= 10;
      }
      get_user_reputation(user) {
        return this.reputations[user] || 0;
      }
      increase_reputation(user, amount) {
        if (!this.reputations[user]) {
          this.reputations[user] = 0;
        }
        this.reputations[user] += amount;
        this.save_reputations();
      }
      save_reputations() {
        localStorage.setItem("terra_user_reputations", JSON.stringify(this.reputations));
      }
      get_all_users_reputation() {
        return this.reputations;
      }
    }
    class DAO {
      constructor() {
        this.vote_system = new VoteSystem();
        this.reputation_system = new ReputationSystem();
      }
      submit_vote(proposal, user) {
        if (this.reputation_system.check_user_eligibility(user)) {
          this.vote_system.register_vote(proposal, user);
          this.reputation_system.increase_reputation(user, 2);
          return { success: true, message: "Vote registered successfully" };
        } else {
          throw new Error("User not eligible to vote - insufficient reputation");
        }
      }
      validate_proposal(proposal) {
        return this.vote_system.is_valid(proposal);
      }
      create_proposal(title, description, user, min_votes = 3) {
        if (!this.reputation_system.check_user_eligibility(user)) {
          throw new Error("User not eligible to create proposals");
        }
        const proposal = {
          title,
          description,
          creator: user,
          min_votes_required: min_votes,
          type: "educational_content"
        };
        return this.vote_system.add_proposal(proposal);
      }
      get_dao_stats() {
        const proposals = this.vote_system.get_all_proposals();
        const reputations = this.reputation_system.get_all_users_reputation();
        return {
          total_proposals: proposals.length,
          active_proposals: proposals.filter((p) => p.status === "active").length,
          total_voters: Object.keys(reputations).length,
          eligible_voters: Object.keys(reputations).filter((user) => reputations[user] >= 10).length
        };
      }
      get_user_dao_activity(user) {
        const proposals = this.vote_system.get_all_proposals();
        const created_proposals = proposals.filter((p) => p.creator === user);
        const reputation = this.reputation_system.get_user_reputation(user);
        return {
          reputation,
          proposals_created: created_proposals.length,
          can_vote: this.reputation_system.check_user_eligibility(user),
          can_create_proposals: this.reputation_system.check_user_eligibility(user)
        };
      }
    }
    return new DAO();
  };
  const simulateKnowledgeEconomy = () => {
    class TokenSystem {
      constructor() {
        this.user_tokens = JSON.parse(localStorage.getItem("terra_user_tokens") || "{}");
      }
      issue_tokens(user, amount) {
        if (!this.user_tokens[user]) {
          this.user_tokens[user] = 0;
        }
        this.user_tokens[user] += amount;
        this.save_tokens();
        return this.user_tokens[user];
      }
      get_user_balance(user) {
        return this.user_tokens[user] || 0;
      }
      save_tokens() {
        localStorage.setItem("terra_user_tokens", JSON.stringify(this.user_tokens));
      }
      get_all_users() {
        return Object.keys(this.user_tokens);
      }
      get_total_tokens() {
        return Object.values(this.user_tokens).reduce((sum, tokens) => sum + tokens, 0);
      }
    }
    class KnowledgeEconomy {
      constructor() {
        this.token_system = new TokenSystem();
      }
      reward_user_for_contribution(user, contribution_type) {
        const reward_amount = this.calculate_reward(contribution_type);
        const new_balance = this.token_system.issue_tokens(user, reward_amount);
        const dao = simulateDAO();
        dao.reputation_system.increase_reputation(user, Math.floor(reward_amount / 2));
        const transaction = {
          user,
          contribution_type,
          reward_amount,
          reputation_gained: Math.floor(reward_amount / 2),
          new_balance,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        };
        const transactions = JSON.parse(localStorage.getItem("terra_transactions") || "[]");
        transactions.push(transaction);
        localStorage.setItem("terra_transactions", JSON.stringify(transactions));
        return transaction;
      }
      calculate_reward(contribution_type) {
        const rewards = {
          "content_creation": 10,
          // токенов за создание контента
          "research": 15,
          // токенов за исследование
          "education": 8,
          // токенов за образовательный контент
          "community": 12,
          // токенов за развитие сообщества
          "innovation": 20,
          // токенов за инновации
          "sustainability": 18
          // токенов за экологические проекты
        };
        return rewards[contribution_type] || 5;
      }
      get_user_stats(user) {
        const transactions = JSON.parse(localStorage.getItem("terra_transactions") || "[]");
        const user_transactions = transactions.filter((t) => t.user === user);
        return {
          total_contributions: user_transactions.length,
          total_tokens: this.token_system.get_user_balance(user),
          contribution_types: [...new Set(user_transactions.map((t) => t.contribution_type))],
          last_contribution: user_transactions.length > 0 ? user_transactions[user_transactions.length - 1] : null
        };
      }
    }
    return new KnowledgeEconomy();
  };
  const testComponent = (componentKey) => {
    const component = architectureComponents[componentKey];
    if (componentKey === "KnowledgeDB") {
      const knowledgeDB = simulateGlobalKnowledgeDB();
      const contexts = knowledgeDB.get_all_contexts();
      const testContext = contexts[Math.floor(Math.random() * contexts.length)];
      const queryResult = knowledgeDB.query(testContext);
      alert(`\u{1F5C4}\uFE0F \u0422\u0435\u0441\u0442 GlobalKnowledgeDB:

\u{1F50D} \u0417\u0430\u043F\u0440\u043E\u0441 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430: "${testContext}"
\u{1F4C4} \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: "${queryResult}"
\u{1F4CA} \u0412\u0441\u0435\u0433\u043E \u0437\u0430\u043F\u0438\u0441\u0435\u0439: ${knowledgeDB.get_data_size()}
\u{1F527} \u041C\u0435\u0442\u043E\u0434\u044B: query(), add_data(), save_data()
\u2705 \u0421\u0442\u0430\u0442\u0443\u0441: \u041F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u0435\u043D`);
      return;
    }
    if (componentKey === "DAOReputation") {
      const dao = simulateDAO();
      const stats = dao.get_dao_stats();
      const testUser = "TerraUser2025";
      const userActivity = dao.get_user_dao_activity(testUser);
      let proposalMessage = "";
      try {
        if (userActivity.can_create_proposals) {
          const proposal = dao.create_proposal(
            "\u0423\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u0435 \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043E\u043D\u0442\u0435\u043D\u0442\u0430",
            "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043F\u043E \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0438\u044E \u043D\u043E\u0432\u044B\u0445 \u0438\u043D\u0442\u0435\u0440\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u043E\u0432",
            testUser
          );
          proposalMessage = `

\u{1F4DD} \u0421\u043E\u0437\u0434\u0430\u043D\u043E \u0442\u0435\u0441\u0442\u043E\u0432\u043E\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435: "${proposal.title}"
\u{1F194} ID: ${proposal.id}`;
        }
      } catch (error) {
        proposalMessage = `

\u274C \u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F: ${error.message}`;
      }
      alert(`\u{1F3DB}\uFE0F \u0422\u0435\u0441\u0442 DAO System:

\u{1F4CA} \u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430 DAO:
\u{1F465} \u0412\u0441\u0435\u0433\u043E \u0433\u043E\u043B\u043E\u0441\u0443\u044E\u0449\u0438\u0445: ${stats.total_voters}
\u2705 \u041F\u0440\u0430\u0432\u043E \u0433\u043E\u043B\u043E\u0441\u0430: ${stats.eligible_voters}
\u{1F4CB} \u0412\u0441\u0435\u0433\u043E \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0439: ${stats.total_proposals}
\u{1F525} \u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435: ${stats.active_proposals}

\u{1F464} \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C ${testUser}:
\u2B50 \u0420\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F: ${userActivity.reputation}
\u{1F5F3}\uFE0F \u041C\u043E\u0436\u0435\u0442 \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u0442\u044C: ${userActivity.can_vote ? "\u0414\u0430" : "\u041D\u0435\u0442"}
\u{1F4DD} \u041C\u043E\u0436\u0435\u0442 \u0441\u043E\u0437\u0434\u0430\u0432\u0430\u0442\u044C: ${userActivity.can_create_proposals ? "\u0414\u0430" : "\u041D\u0435\u0442"}${proposalMessage}

\u{1F527} \u041C\u0435\u0442\u043E\u0434\u044B: submit_vote(), validate_proposal(), create_proposal()`);
      return;
    }
    const testResult = {
      component: component.title,
      status: "tested",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      performance: Math.floor(Math.random() * 20) + 80,
      // 80-100%
      features_active: component.features.length,
      integration_score: Math.floor(Math.random() * 15) + 85
      // 85-100%
    };
    alert(`\u{1F9EA} \u0422\u0435\u0441\u0442 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430: ${component.title}

\u2705 \u0421\u0442\u0430\u0442\u0443\u0441: \u0423\u0441\u043F\u0435\u0448\u043D\u043E
\u{1F4CA} \u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C: ${testResult.performance}%
\u{1F517} \u0418\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F: ${testResult.integration_score}%
\u2699\uFE0F \u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438: ${testResult.features_active}`);
  };
  return /* @__PURE__ */ React.createElement("div", { className: "w-full h-full bg-gradient-to-br from-slate-50 to-blue-50 p-6 overflow-auto" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto" }, /* @__PURE__ */ React.createElement("div", { className: "text-center mb-8" }, /* @__PURE__ */ React.createElement("h1", { className: "text-4xl font-bold bg-gradient-to-r from-blue-600 via-green-600 to-purple-600 bg-clip-text text-transparent mb-2" }, "\u{1F3D7}\uFE0F Terra OS Educational Architecture"), /* @__PURE__ */ React.createElement("p", { className: "text-lg text-gray-600" }, "\u0418\u043D\u0442\u0435\u0433\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u044D\u043A\u043E\u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u0441 AR \u0438 DAO"), /* @__PURE__ */ React.createElement("div", { className: "mt-4 bg-gradient-to-r from-blue-100 to-green-100 border border-blue-300 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("p", { className: "text-blue-800 text-sm" }, /* @__PURE__ */ React.createElement("strong", null, "\u{1F3AF} \u0410\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u0430:"), " SemanticKernel \u2192 EducationModule \u2192 KnowledgeDB + \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044E\u0449\u0438\u0435 \u0441\u043B\u043E\u0438"))), /* @__PURE__ */ React.createElement("div", { className: "mb-8 bg-white rounded-xl shadow-lg p-8 border" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-gray-900 mb-6 text-center" }, "\u{1F4D0} \u0410\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u043D\u0430\u044F \u0434\u0438\u0430\u0433\u0440\u0430\u043C\u043C\u0430"), /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-center mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-4" }, ["SemanticKernel", "EducationModule", "KnowledgeDB"].map((comp, index) => /* @__PURE__ */ React.createElement("div", { key: comp, className: "flex items-center" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveComponent(comp),
      className: `p-4 rounded-xl border-2 transition-all duration-300 transform hover:scale-105 ${activeComponent === comp ? `bg-gradient-to-r ${architectureComponents[comp].color} text-white border-transparent shadow-lg` : "bg-white border-gray-300 hover:border-blue-400"}`
    },
    /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl mb-1" }, architectureComponents[comp].title.split(" ")[0]), /* @__PURE__ */ React.createElement("div", { className: "text-sm font-medium" }, architectureComponents[comp].title.split(" ").slice(1).join(" ")))
  ), index < 2 && /* @__PURE__ */ React.createElement("div", { className: "mx-4 text-2xl text-gray-400" }, "\u2192"))))), /* @__PURE__ */ React.createElement("div", { className: "flex justify-center space-x-8" }, ["EthicalLayer", "ARInterface", "DAOReputation"].map((comp) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: comp,
      onClick: () => setActiveComponent(comp),
      className: `p-3 rounded-lg border transition-all duration-300 ${activeComponent === comp ? `bg-gradient-to-r ${architectureComponents[comp].color} text-white border-transparent` : "bg-gray-50 border-gray-300 hover:border-gray-400"}`
    },
    /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xl mb-1" }, architectureComponents[comp].title.split(" ")[0]), /* @__PURE__ */ React.createElement("div", { className: "text-xs" }, architectureComponents[comp].title.split(" ").slice(1).join(" ")))
  ))), /* @__PURE__ */ React.createElement("div", { className: "mt-6 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-500 mb-2" }, "\u0421\u0432\u044F\u0437\u0438 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u043E\u0432:"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400" }, "SemanticKernel \u2194 EthicalLayer | EducationModule \u2194 ARInterface | KnowledgeDB \u2194 DAO & Reputation"))), /* @__PURE__ */ React.createElement("div", { className: "grid lg:grid-cols-2 gap-8 mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6 border" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-gray-900 mb-6" }, "\u{1F50D} \u0414\u0435\u0442\u0430\u043B\u0438 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430"), activeComponent && /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: `p-4 rounded-lg bg-gradient-to-r ${architectureComponents[activeComponent].color} text-white mb-4` }, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-bold mb-2" }, architectureComponents[activeComponent].title), /* @__PURE__ */ React.createElement("p", { className: "text-sm opacity-90" }, architectureComponents[activeComponent].description)), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold text-gray-900 mb-2" }, "\u{1F3AF} \u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438:"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 gap-2" }, architectureComponents[activeComponent].features.map((feature, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex items-center space-x-2 p-2 bg-gray-50 rounded" }, /* @__PURE__ */ React.createElement("span", { className: "text-green-500" }, "\u2713"), /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-700" }, feature))))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold text-gray-900 mb-2" }, "\u{1F517} \u0421\u0432\u044F\u0437\u0438:"), /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap gap-2" }, architectureComponents[activeComponent].connections.length > 0 ? architectureComponents[activeComponent].connections.map((conn) => /* @__PURE__ */ React.createElement("span", { key: conn, className: "px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm" }, architectureComponents[conn].title)) : /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-500" }, "\u041A\u043E\u043D\u0435\u0447\u043D\u0430\u044F \u0442\u043E\u0447\u043A\u0430 \u0430\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u044B"))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => testComponent(activeComponent),
      className: "w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
    },
    "\u{1F9EA} \u041F\u0440\u043E\u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442"
  )))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6 border" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-gray-900 mb-6" }, "\u{1F4CA} \u041C\u0435\u0442\u0440\u0438\u043A\u0438 \u0441\u0438\u0441\u0442\u0435\u043C\u044B"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 gap-4 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-blue-50 rounded-lg p-4 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-blue-600" }, educationMetrics.students_connected), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-blue-800" }, "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043D\u044B\u0435 \u0441\u0442\u0443\u0434\u0435\u043D\u0442\u044B")), /* @__PURE__ */ React.createElement("div", { className: "bg-green-50 rounded-lg p-4 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-green-600" }, educationMetrics.knowledge_units), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-green-800" }, "\u0415\u0434\u0438\u043D\u0438\u0446\u044B \u0437\u043D\u0430\u043D\u0438\u0439")), /* @__PURE__ */ React.createElement("div", { className: "bg-purple-50 rounded-lg p-4 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-purple-600" }, educationMetrics.ar_sessions), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-purple-800" }, "AR \u0441\u0435\u0441\u0441\u0438\u0438")), /* @__PURE__ */ React.createElement("div", { className: "bg-amber-50 rounded-lg p-4 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-amber-600" }, educationMetrics.dao_votes), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-amber-800" }, "DAO \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043D\u0438\u044F"))), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "font-semibold text-gray-900 mb-3" }, "\u2696\uFE0F \u042D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0432\u0430\u043B\u0438\u0434\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4 border border-green-200" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-green-800" }, "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438"), /* @__PURE__ */ React.createElement("span", { className: "text-2xl font-bold text-green-600" }, educationMetrics.ethical_validations)), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-green-700 mt-2" }, "\u0412\u0441\u0435 \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u043F\u0440\u043E\u0445\u043E\u0434\u044F\u0442 \u044D\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0432\u0430\u043B\u0438\u0434\u0430\u0446\u0438\u044E"))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: runDataFlowSimulation,
      disabled: simulationRunning,
      className: "w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
    },
    simulationRunning ? "\u{1F504} \u0421\u0438\u043C\u0443\u043B\u044F\u0446\u0438\u044F \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F..." : "\u{1F680} \u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u0438\u043C\u0443\u043B\u044F\u0446\u0438\u044E \u043F\u043E\u0442\u043E\u043A\u0430 \u0434\u0430\u043D\u043D\u044B\u0445"
  ))), dataFlow.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6 border mb-8" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-gray-900 mb-6" }, "\u{1F30A} \u041F\u043E\u0442\u043E\u043A \u0434\u0430\u043D\u043D\u044B\u0445 \u0432 \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0438"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3 max-h-64 overflow-y-auto" }, dataFlow.map((step, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border" }, /* @__PURE__ */ React.createElement("span", { className: "bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold" }, index + 1), /* @__PURE__ */ React.createElement("span", { className: "text-gray-800" }, step), /* @__PURE__ */ React.createElement("span", { className: "text-green-500 ml-auto" }, "\u2713")))), simulationRunning && /* @__PURE__ */ React.createElement("div", { className: "mt-4 flex items-center justify-center space-x-2" }, /* @__PURE__ */ React.createElement("div", { className: "animate-spin w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full" }), /* @__PURE__ */ React.createElement("span", { className: "text-blue-600 text-sm" }, "\u041E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0432 \u0430\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u0435 Terra OS..."))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6 border mb-8" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-gray-900 mb-6" }, "\u{1F4B0} Enhanced Knowledge Economy - \u0416\u0438\u0432\u0430\u044F \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "mb-6 bg-gradient-to-r from-red-50 to-pink-50 rounded-lg p-4 border border-red-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-red-900 mb-4" }, "\u{1F3DB}\uFE0F DAO Governance System v1.0"), /* @__PURE__ */ React.createElement("div", { className: "grid md:grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900 mb-3" }, "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0434\u043B\u044F \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043D\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      id: "proposal-title",
      placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F...",
      className: "w-full p-2 border border-gray-300 rounded-lg text-sm",
      defaultValue: "\u041D\u043E\u0432\u044B\u0439 \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043C\u043E\u0434\u0443\u043B\u044C"
    }
  ), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      id: "proposal-description",
      placeholder: "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F...",
      className: "w-full p-2 border border-gray-300 rounded-lg text-sm h-20 resize-none",
      defaultValue: "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0438\u043D\u0442\u0435\u0440\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 AR-\u0443\u0440\u043E\u043A\u043E\u0432 \u043F\u043E \u043A\u0432\u0430\u043D\u0442\u043E\u0432\u043E\u0439 \u0444\u0438\u0437\u0438\u043A\u0435"
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const dao = simulateDAO();
        const userName = document.getElementById("user-name").value || "TerraUser2025";
        const title = document.getElementById("proposal-title").value;
        const description = document.getElementById("proposal-description").value;
        try {
          const proposal = dao.create_proposal(title, description, userName, 3);
          const userActivity = dao.get_user_dao_activity(userName);
          alert(`\u{1F3DB}\uFE0F \u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u043E!

\u{1F4DD} \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435: ${proposal.title}
\u{1F194} ID: ${proposal.id}
\u{1F464} \u0421\u043E\u0437\u0434\u0430\u0442\u0435\u043B\u044C: ${userName}
\u2B50 \u0420\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F: ${userActivity.reputation}
\u{1F5F3}\uFE0F \u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0433\u043E\u043B\u043E\u0441\u043E\u0432: ${proposal.min_votes_required}
\u{1F4C5} \u0421\u043E\u0437\u0434\u0430\u043D\u043E: ${new Date(proposal.created_at).toLocaleString()}`);
          setEducationMetrics((prev) => ({
            ...prev,
            dao_votes: prev.dao_votes + 1
          }));
        } catch (error) {
          alert(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F:

${error.message}

\u{1F4A1} \u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430: \u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0432\u043A\u043B\u0430\u0434\u043E\u0432 \u0434\u043B\u044F \u0443\u0432\u0435\u043B\u0438\u0447\u0435\u043D\u0438\u044F \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438 (\u043C\u0438\u043D\u0438\u043C\u0443\u043C 10 \u043E\u0447\u043A\u043E\u0432)`);
        }
      },
      className: "w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors"
    },
    "\u{1F3DB}\uFE0F \u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 DAO"
  ))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900 mb-3" }, "\u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430 DAO \u0438 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const dao = simulateDAO();
        const userName = document.getElementById("user-name").value || "TerraUser2025";
        const stats = dao.get_dao_stats();
        const userActivity = dao.get_user_dao_activity(userName);
        const proposals = dao.vote_system.get_all_proposals();
        let proposalsList = "";
        if (proposals.length > 0) {
          proposalsList = "\n\n\u{1F4CB} \u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F:\n";
          proposals.slice(-3).forEach((prop, i) => {
            const votes = dao.vote_system.get_proposal_votes(prop.id);
            proposalsList += `${i + 1}. ${prop.title} (${votes}/${prop.min_votes_required} \u0433\u043E\u043B\u043E\u0441\u043E\u0432)
`;
          });
        }
        alert(`\u{1F3DB}\uFE0F \u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430 DAO \u0441\u0438\u0441\u0442\u0435\u043C\u044B:

\u{1F4CA} \u041E\u0431\u0449\u0430\u044F \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430:
\u{1F465} \u0412\u0441\u0435\u0433\u043E \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432: ${stats.total_voters}
\u2705 \u041C\u043E\u0433\u0443\u0442 \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u0442\u044C: ${stats.eligible_voters}
\u{1F4CB} \u0412\u0441\u0435\u0433\u043E \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0439: ${stats.total_proposals}
\u{1F525} \u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0445: ${stats.active_proposals}

\u{1F464} ${userName}:
\u2B50 \u0420\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F: ${userActivity.reputation}
\u{1F5F3}\uFE0F \u041F\u0440\u0430\u0432\u043E \u0433\u043E\u043B\u043E\u0441\u0430: ${userActivity.can_vote ? "\u0415\u0441\u0442\u044C" : "\u041D\u0435\u0442"}
\u{1F4DD} \u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0439: ${userActivity.can_create_proposals ? "\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u043E" : "\u041D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E"}
\u{1F4C8} \u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0439 \u0441\u043E\u0437\u0434\u0430\u043D\u043E: ${userActivity.proposals_created}${proposalsList}`);
      },
      className: "w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors mb-3"
    },
    "\u{1F4CA} \u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430 DAO"
  ), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-red-800 mb-1" }, "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-red-600 space-y-1" }, /* @__PURE__ */ React.createElement("div", null, "\u2B50 \u041C\u0438\u043D\u0438\u043C\u0443\u043C \u0434\u043B\u044F \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043D\u0438\u044F: 10 \u043E\u0447\u043A\u043E\u0432"), /* @__PURE__ */ React.createElement("div", null, "\u{1F4DD} \u0412\u043A\u043B\u0430\u0434 = \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F/2 \u043E\u0447\u043A\u043E\u0432"), /* @__PURE__ */ React.createElement("div", null, "\u{1F5F3}\uFE0F \u0413\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043D\u0438\u0435 = +2 \u043E\u0447\u043A\u0430"), /* @__PURE__ */ React.createElement("div", null, "\u{1F3DB}\uFE0F \u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0439 = \u043F\u0440\u0430\u0432\u043E \u0433\u043E\u043B\u043E\u0441\u0430"))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const dao = simulateDAO();
        const userName = document.getElementById("user-name").value || "TerraUser2025";
        const proposals = dao.vote_system.get_all_proposals();
        if (proposals.length > 0) {
          const randomProposal = proposals[Math.floor(Math.random() * proposals.length)];
          try {
            const result = dao.submit_vote(randomProposal, userName);
            const votes = dao.vote_system.get_proposal_votes(randomProposal.id);
            const isValid = dao.validate_proposal(randomProposal);
            alert(`\u{1F5F3}\uFE0F \u0413\u043E\u043B\u043E\u0441 \u043F\u043E\u0434\u0430\u043D!

\u{1F4DD} \u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435: ${randomProposal.title}
\u{1F464} \u0413\u043E\u043B\u043E\u0441\u0443\u044E\u0449\u0438\u0439: ${userName}
\u2705 \u0421\u0442\u0430\u0442\u0443\u0441: ${result.message}
\u{1F4CA} \u0422\u0435\u043A\u0443\u0449\u0438\u0445 \u0433\u043E\u043B\u043E\u0441\u043E\u0432: ${votes}/${randomProposal.min_votes_required}
\u{1F3AF} \u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u043E: ${isValid ? "\u0414\u0430" : "\u041D\u0435\u0442"}
\u2B50 \u0420\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F +2`);
          } catch (error) {
            alert(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043D\u0438\u044F:

${error.message}`);
          }
        } else {
          alert("\u{1F4DD} \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0434\u043B\u044F \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043D\u0438\u044F!");
        }
      },
      className: "w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
    },
    "\u{1F5F3}\uFE0F \u041F\u0440\u043E\u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u0442\u044C"
  ))))), /* @__PURE__ */ React.createElement("div", { className: "mb-6 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-lg p-4 border border-amber-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-amber-900 mb-4" }, "\u{1F3AE} \u0421\u0438\u043C\u0443\u043B\u044F\u0442\u043E\u0440 \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u043A\u0438 \u0437\u043D\u0430\u043D\u0438\u0439 v2.0"), /* @__PURE__ */ React.createElement("div", { className: "grid md:grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900 mb-3" }, "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0432\u043A\u043B\u0430\u0434 \u0438 \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u0442\u043E\u043A\u0435\u043D\u044B"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, /* @__PURE__ */ React.createElement(
    "select",
    {
      id: "enhanced-contribution-type",
      className: "w-full p-2 border border-gray-300 rounded-lg text-sm"
    },
    /* @__PURE__ */ React.createElement("option", { value: "content_creation" }, "\u{1F4DD} \u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u043A\u043E\u043D\u0442\u0435\u043D\u0442\u0430 (10 \u0442\u043E\u043A\u0435\u043D\u043E\u0432)"),
    /* @__PURE__ */ React.createElement("option", { value: "research" }, "\u{1F52C} \u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 (15 \u0442\u043E\u043A\u0435\u043D\u043E\u0432)"),
    /* @__PURE__ */ React.createElement("option", { value: "education" }, "\u{1F393} \u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435 (8 \u0442\u043E\u043A\u0435\u043D\u043E\u0432)"),
    /* @__PURE__ */ React.createElement("option", { value: "community" }, "\u{1F465} \u0421\u043E\u043E\u0431\u0449\u0435\u0441\u0442\u0432\u043E (12 \u0442\u043E\u043A\u0435\u043D\u043E\u0432)"),
    /* @__PURE__ */ React.createElement("option", { value: "innovation" }, "\u{1F4A1} \u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u0438 (20 \u0442\u043E\u043A\u0435\u043D\u043E\u0432)"),
    /* @__PURE__ */ React.createElement("option", { value: "sustainability" }, "\u{1F331} \u042D\u043A\u043E\u043B\u043E\u0433\u0438\u044F (18 \u0442\u043E\u043A\u0435\u043D\u043E\u0432)")
  ), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      id: "user-name",
      placeholder: "\u0412\u0430\u0448\u0435 \u0438\u043C\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F...",
      className: "w-full p-2 border border-gray-300 rounded-lg text-sm",
      defaultValue: "TerraUser2025"
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const contributionType = document.getElementById("enhanced-contribution-type").value;
        const userName = document.getElementById("user-name").value || "TerraUser2025";
        const knowledgeEconomy = simulateKnowledgeEconomy();
        const transaction = knowledgeEconomy.reward_user_for_contribution(userName, contributionType);
        const contributionNames = {
          "content_creation": "\u{1F4DD} \u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u043A\u043E\u043D\u0442\u0435\u043D\u0442\u0430",
          "research": "\u{1F52C} \u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435",
          "education": "\u{1F393} \u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435",
          "community": "\u{1F465} \u0421\u043E\u043E\u0431\u0449\u0435\u0441\u0442\u0432\u043E",
          "innovation": "\u{1F4A1} \u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u0438",
          "sustainability": "\u{1F331} \u042D\u043A\u043E\u043B\u043E\u0433\u0438\u044F"
        };
        alert(`\u{1F389} \u0412\u043A\u043B\u0430\u0434 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D!

\u{1F464} \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C: ${userName}
\u{1F4BC} \u0422\u0438\u043F: ${contributionNames[contributionType]}
\u{1F4B0} \u041D\u0430\u0433\u0440\u0430\u0434\u0430: +${transaction.reward_amount} TERRA \u0442\u043E\u043A\u0435\u043D\u043E\u0432
\u2B50 \u0420\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F: +${transaction.reputation_gained} \u043E\u0447\u043A\u043E\u0432
\u{1F3E6} \u041D\u043E\u0432\u044B\u0439 \u0431\u0430\u043B\u0430\u043D\u0441: ${transaction.new_balance} \u0442\u043E\u043A\u0435\u043D\u043E\u0432
\u{1F4C5} \u0412\u0440\u0435\u043C\u044F: ${new Date(transaction.timestamp).toLocaleString()}`);
        setEducationMetrics((prev) => ({
          ...prev,
          knowledge_units: prev.knowledge_units + transaction.reward_amount,
          students_connected: Math.max(prev.students_connected, knowledgeEconomy.token_system.get_all_users().length),
          dao_votes: prev.dao_votes + Math.floor(Math.random() * 2)
        }));
      },
      className: "w-full bg-amber-600 text-white py-2 px-4 rounded-lg hover:bg-amber-700 transition-colors"
    },
    "\u{1F4B0} \u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043D\u0430\u0433\u0440\u0430\u0434\u0443 TERRA"
  ))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900 mb-3" }, "\u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430 \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u043A\u0438"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const knowledgeEconomy = simulateKnowledgeEconomy();
        const userName = document.getElementById("user-name").value || "TerraUser2025";
        const stats = knowledgeEconomy.get_user_stats(userName);
        const totalUsers = knowledgeEconomy.token_system.get_all_users().length;
        const totalTokens = knowledgeEconomy.token_system.get_total_tokens();
        let statsMessage = `\u{1F4CA} \u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F: ${userName}

`;
        statsMessage += `\u{1F4B0} \u0412\u0441\u0435\u0433\u043E \u0442\u043E\u043A\u0435\u043D\u043E\u0432: ${stats.total_tokens}
`;
        statsMessage += `\u{1F4C8} \u0412\u0441\u0435\u0433\u043E \u0432\u043A\u043B\u0430\u0434\u043E\u0432: ${stats.total_contributions}
`;
        statsMessage += `\u{1F3AF} \u0422\u0438\u043F\u044B \u0432\u043A\u043B\u0430\u0434\u043E\u0432: ${stats.contribution_types.join(", ") || "\u041D\u0435\u0442"}

`;
        statsMessage += `\u{1F30D} \u0413\u043B\u043E\u0431\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430:
`;
        statsMessage += `\u{1F465} \u0412\u0441\u0435\u0433\u043E \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u0439: ${totalUsers}
`;
        statsMessage += `\u{1F48E} \u0412\u0441\u0435\u0433\u043E \u0442\u043E\u043A\u0435\u043D\u043E\u0432 \u0432 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u0438: ${totalTokens}`;
        if (stats.last_contribution) {
          statsMessage += `

\u{1F552} \u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u0432\u043A\u043B\u0430\u0434:
`;
          statsMessage += `\u{1F4DD} \u0422\u0438\u043F: ${stats.last_contribution.contribution_type}
`;
          statsMessage += `\u{1F4B0} \u041D\u0430\u0433\u0440\u0430\u0434\u0430: ${stats.last_contribution.reward_amount} \u0442\u043E\u043A\u0435\u043D\u043E\u0432`;
        }
        alert(statsMessage);
      },
      className: "w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors mb-3"
    },
    "\u{1F4CA} \u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0443"
  ), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-green-800 mb-1" }, "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0432\u043E\u0437\u043D\u0430\u0433\u0440\u0430\u0436\u0434\u0435\u043D\u0438\u0439"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-green-600 space-y-1" }, /* @__PURE__ */ React.createElement("div", null, "\u{1F4A1} \u0418\u043D\u043D\u043E\u0432\u0430\u0446\u0438\u0438: 20 \u0442\u043E\u043A\u0435\u043D\u043E\u0432 + 10 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", null, "\u{1F331} \u042D\u043A\u043E\u043B\u043E\u0433\u0438\u044F: 18 \u0442\u043E\u043A\u0435\u043D\u043E\u0432 + 9 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", null, "\u{1F52C} \u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F: 15 \u0442\u043E\u043A\u0435\u043D\u043E\u0432 + 7 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", null, "\u{1F465} \u0421\u043E\u043E\u0431\u0449\u0435\u0441\u0442\u0432\u043E: 12 \u0442\u043E\u043A\u0435\u043D\u043E\u0432 + 6 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", null, "\u{1F4DD} \u041A\u043E\u043D\u0442\u0435\u043D\u0442: 10 \u0442\u043E\u043A\u0435\u043D\u043E\u0432 + 5 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438"), /* @__PURE__ */ React.createElement("div", null, "\u{1F393} \u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435: 8 \u0442\u043E\u043A\u0435\u043D\u043E\u0432 + 4 \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u0438"))))))), /* @__PURE__ */ React.createElement("div", { className: "border-t pt-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-gray-900 mb-4" }, "\u{1F5C4}\uFE0F GlobalKnowledgeDB Integration"), /* @__PURE__ */ React.createElement("div", { className: "grid md:grid-cols-2 gap-6 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-purple-900 mb-4" }, "\u{1F4DD} Python \u041A\u043B\u0430\u0441\u0441"), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-900 rounded-lg p-4 text-green-400 text-xs font-mono" }, /* @__PURE__ */ React.createElement("div", null, "class GlobalKnowledgeDB:"), /* @__PURE__ */ React.createElement("div", null, "\xA0\xA0def __init__(self):"), /* @__PURE__ */ React.createElement("div", null, "\xA0\xA0\xA0\xA0self.data = ", "{}"), /* @__PURE__ */ React.createElement("div", null), /* @__PURE__ */ React.createElement("div", null, "\xA0\xA0def query(self, context):"), /* @__PURE__ */ React.createElement("div", null, '\xA0\xA0\xA0\xA0return self.data.get(context, "No info")'), /* @__PURE__ */ React.createElement("div", null), /* @__PURE__ */ React.createElement("div", null, "\xA0\xA0def add_data(self, context, new_data):"), /* @__PURE__ */ React.createElement("div", null, "\xA0\xA0\xA0\xA0self.data[context] = new_data"), /* @__PURE__ */ React.createElement("div", null, "\xA0\xA0\xA0\xA0self.save_data()"))), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-blue-900 mb-4" }, "\u269B\uFE0F Enhanced React Implementation"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-blue-800 mb-1" }, "\u2705 KnowledgeEconomy \u043A\u043B\u0430\u0441\u0441"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-blue-600" }, "reward_user_for_contribution() \u0440\u0435\u0430\u043B\u0438\u0437\u043E\u0432\u0430\u043D")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-indigo-800 mb-1" }, "\u2705 TokenSystem \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-indigo-600" }, "issue_tokens(), get_user_balance()")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-purple-800 mb-1" }, "\u2705 \u0414\u0435\u0442\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043D\u0430\u0433\u0440\u0430\u0434\u044B"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-purple-600" }, "6 \u0442\u0438\u043F\u043E\u0432 \u0432\u043A\u043B\u0430\u0434\u043E\u0432 + \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-green-800 mb-1" }, "\u2705 \u0422\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0438 \u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-green-600" }, "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0432\u043A\u043B\u0430\u0434\u043E\u0432 \u0438 \u0431\u0430\u043B\u0430\u043D\u0441\u044B")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-red-800 mb-1" }, "\u2705 DAO \u0441\u0438\u0441\u0442\u0435\u043C\u0430"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-red-600" }, "submit_vote(), validate_proposal(), \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F"))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4 border border-green-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-green-900 mb-4" }, "\u{1F680} \u0424\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C GlobalKnowledgeDB"), /* @__PURE__ */ React.createElement("div", { className: "grid md:grid-cols-4 gap-4 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl mb-2" }, "\u{1F50D}"), /* @__PURE__ */ React.createElement("div", { className: "font-medium text-green-800 mb-1" }, "Context Query"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-green-600" }, "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0443")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl mb-2" }, "\u{1F4DD}"), /* @__PURE__ */ React.createElement("div", { className: "font-medium text-blue-800 mb-1" }, "Data Addition"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-blue-600" }, "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043D\u043E\u0432\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl mb-2" }, "\u{1F4BE}"), /* @__PURE__ */ React.createElement("div", { className: "font-medium text-purple-800 mb-1" }, "Auto Save"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-purple-600" }, "\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl mb-2" }, "\u{1F4CA}"), /* @__PURE__ */ React.createElement("div", { className: "font-medium text-amber-800 mb-1" }, "Data Analytics"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-amber-600" }, "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u0431\u0430\u0437\u044B \u0437\u043D\u0430\u043D\u0438\u0439"))), /* @__PURE__ */ React.createElement("div", { className: "mt-4 bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900 mb-2" }, "\u{1F3AF} \u0418\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F \u0432 Terra Architecture"), /* @__PURE__ */ React.createElement("div", { className: "grid md:grid-cols-3 gap-3 text-xs" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-blue-800" }, "SemanticKernel"), /* @__PURE__ */ React.createElement("div", { className: "text-blue-600" }, "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 GlobalKnowledgeDB.query() \u0434\u043B\u044F \u0438\u0437\u0432\u043B\u0435\u0447\u0435\u043D\u0438\u044F \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-green-800" }, "EducationModule"), /* @__PURE__ */ React.createElement("div", { className: "text-green-600" }, "\u0414\u043E\u0431\u0430\u0432\u043B\u044F\u0435\u0442 \u043D\u043E\u0432\u044B\u0435 \u0437\u043D\u0430\u043D\u0438\u044F \u0447\u0435\u0440\u0435\u0437 add_data()")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-purple-800" }, "Data Persistence"), /* @__PURE__ */ React.createElement("div", { className: "text-purple-600" }, "save_data() \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0438\u0432\u0430\u0435\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u043D\u043E\u0441\u0442\u044C"))))))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl shadow-lg p-6 border" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-gray-900 mb-6" }, "\u{1F393} \u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "grid md:grid-cols-3 gap-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-blue-900 mb-4" }, "\u{1F4DA} Semantic Learning"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-blue-800 mb-1" }, "\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u043D\u043E\u0435 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-blue-600" }, "\u0410\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044F \u043A \u0441\u0442\u0438\u043B\u044E \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u0441\u0442\u0443\u0434\u0435\u043D\u0442\u0430")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-indigo-800 mb-1" }, "\u0417\u043D\u0430\u043D\u0438\u044F \u043A\u0430\u043A \u0433\u0440\u0430\u0444"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-indigo-600" }, "\u0421\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u043A\u043E\u043D\u0446\u0435\u043F\u0446\u0438\u0438 \u0438 \u0438\u0434\u0435\u0438")))), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4 border border-green-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-green-900 mb-4" }, "\u{1F3AE} Interactive Learning"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-green-800 mb-1" }, "AR/VR \u043F\u043E\u0433\u0440\u0443\u0436\u0435\u043D\u0438\u0435"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-green-600" }, "\u0418\u0437\u0443\u0447\u0435\u043D\u0438\u0435 \u0447\u0435\u0440\u0435\u0437 \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0435 \u043C\u0438\u0440\u044B")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-emerald-800 mb-1" }, "\u0413\u0435\u0439\u043C\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-emerald-600" }, "\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u0447\u0435\u0440\u0435\u0437 \u0438\u0433\u0440\u043E\u0432\u044B\u0435 \u043C\u0435\u0445\u0430\u043D\u0438\u043A\u0438")))), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-purple-900 mb-4" }, "\u{1F91D} Social Learning"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-purple-800 mb-1" }, "DAO \u0441\u043E\u043E\u0431\u0449\u0435\u0441\u0442\u0432\u0430"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-purple-600" }, "\u041A\u043E\u043B\u043B\u0435\u043A\u0442\u0438\u0432\u043D\u043E\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0437\u043D\u0430\u043D\u0438\u0439")), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded p-3 border" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium text-pink-800 mb-1" }, "Peer-to-peer"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-pink-600" }, "\u041E\u0431\u0443\u0447\u0435\u043D\u0438\u0435 \u0434\u0440\u0443\u0433 \u0443 \u0434\u0440\u0443\u0433\u0430"))))), /* @__PURE__ */ React.createElement("div", { className: "mt-8 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg p-4 border border-amber-200" }, /* @__PURE__ */ React.createElement("h3", { className: "font-semibold text-amber-900 mb-3" }, "\u{1F30D} \u0418\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F \u0441 Terra Language Core"), /* @__PURE__ */ React.createElement("div", { className: "grid md:grid-cols-2 gap-4 text-sm" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-amber-800 mb-2" }, "\u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u044B:"), /* @__PURE__ */ React.createElement("ul", { className: "space-y-1 text-amber-700" }, /* @__PURE__ */ React.createElement("li", null, "\u2022 \u269B\uFE0F \u041A\u0432\u0430\u0440\u043A\u0438 \u2192 Semantic units \u0434\u043B\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"), /* @__PURE__ */ React.createElement("li", null, "\u2022 \u{1F517} \u041D\u0430\u043D\u043E\u044F\u0434\u0440\u0430 \u2192 Educational contexts"), /* @__PURE__ */ React.createElement("li", null, "\u2022 \u{1F9E0} \u041C\u0438\u043A\u0440\u043E\u044F\u0434\u0440\u043E \u2192 Learning orchestration"), /* @__PURE__ */ React.createElement("li", null, "\u2022 \u{1F4BE} Session tokens \u2192 Progress tracking"))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-orange-800 mb-2" }, "\u041D\u043E\u0432\u044B\u0435 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0438:"), /* @__PURE__ */ React.createElement("ul", { className: "space-y-1 text-orange-700" }, /* @__PURE__ */ React.createElement("li", null, "\u2022 \u{1F393} Adaptive learning paths"), /* @__PURE__ */ React.createElement("li", null, "\u2022 \u{1F97D} AR/VR educational experiences"), /* @__PURE__ */ React.createElement("li", null, "\u2022 \u{1F3DB}\uFE0F DAO-governed curriculum"), /* @__PURE__ */ React.createElement("li", null, "\u2022 \u2696\uFE0F Ethical content validation"))))))));
};
var stdin_default = TerraEducationalArchitecture;
export {
  stdin_default as default
};
