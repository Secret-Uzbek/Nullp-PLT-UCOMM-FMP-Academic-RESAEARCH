// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
var DynamicTerraCodex = () => {
  const [phase, setPhase] = useState(0);
  const [orbitSpeed, setOrbitSpeed] = useState(1);
  const [quantumState, setQuantumState] = useState("coherent");
  const [discoveryMode, setDiscoveryMode] = useState(false);
  const phases = [
    { name: "\u041A\u0432\u0430\u043D\u0442\u043E\u0432\u043E\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435", color: "#00FFB3", symbol: "\u269B\uFE0F" },
    { name: "\u0411\u0438\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435", color: "#32CD32", symbol: "\u{1F9EC}" },
    { name: "\u0414\u0435\u0442\u0441\u043A\u043E\u0435 \u0441\u043E\u0437\u043D\u0430\u043D\u0438\u0435", color: "#FFB6C1", symbol: "\u{1F476}" },
    { name: "\u041F\u043B\u0430\u043D\u0435\u0442\u0430\u0440\u043D\u043E\u0435", color: "#4169E1", symbol: "\u{1F30D}" },
    { name: "\u041A\u043E\u0441\u043C\u0438\u0447\u0435\u0441\u043A\u043E\u0435", color: "#9370DB", symbol: "\u{1F30C}" }
  ];
  const discoveries = [
    "\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u0430\u044F \u043C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u043E\u0441\u0442\u044C",
    "\u041C\u0435\u0436\u0432\u0438\u0434\u043E\u0432\u0430\u044F \u043A\u043E\u043C\u043C\u0443\u043D\u0438\u043A\u0430\u0446\u0438\u044F",
    "\u041A\u0432\u0430\u043D\u0442\u043E\u0432\u043E\u0435 \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435",
    "\u041F\u043B\u0430\u043D\u0435\u0442\u0430\u0440\u043D\u0430\u044F \u043F\u0430\u043C\u044F\u0442\u044C",
    "\u0414\u0435\u0442\u0441\u043A\u043E\u0435 \u0431\u0443\u0434\u0443\u0449\u0435\u0435"
  ];
  useEffect(() => {
    const interval = setInterval(() => {
      setPhase((prev) => (prev + 1) % phases.length);
    }, 3e3);
    return () => clearInterval(interval);
  }, [phases.length]);
  useEffect(() => {
    const speedInterval = setInterval(() => {
      setOrbitSpeed((prev) => prev === 1 ? 2 : prev === 2 ? 0.5 : 1);
    }, 5e3);
    return () => clearInterval(speedInterval);
  }, []);
  useEffect(() => {
    const quantumInterval = setInterval(() => {
      setQuantumState((prev) => prev === "coherent" ? "superposition" : prev === "superposition" ? "entangled" : "coherent");
    }, 4e3);
    return () => clearInterval(quantumInterval);
  }, []);
  const handleDiscovery = () => {
    setDiscoveryMode(true);
    setTimeout(() => setDiscoveryMode(false), 2e3);
  };
  const currentPhase = phases[phase];
  return /* @__PURE__ */ React.createElement("div", { className: "relative w-full h-full min-h-[600px] bg-gradient-to-br from-slate-900 via-indigo-900 to-purple-900 flex flex-col items-center justify-center overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "absolute inset-0" }, [...Array(30)].map((_, i) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: i,
      className: `absolute w-2 h-2 rounded-full transition-all duration-1000 ${quantumState === "superposition" ? "animate-ping" : quantumState === "entangled" ? "animate-pulse" : "animate-bounce"}`,
      style: {
        left: `${Math.random() * 100}%`,
        top: `${Math.random() * 100}%`,
        backgroundColor: currentPhase.color,
        opacity: 0.6,
        animationDelay: `${Math.random() * 2}s`,
        animationDuration: `${1 + Math.random()}s`
      }
    }
  ))), /* @__PURE__ */ React.createElement("div", { className: "text-center mb-8 z-20" }, /* @__PURE__ */ React.createElement("h1", { className: "text-5xl font-bold bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent mb-4" }, "TERRA CODEX"), /* @__PURE__ */ React.createElement("h2", { className: "text-xl text-gray-300 mb-2" }, "\u0416\u0438\u0432\u043E\u0439 \u041B\u043E\u0433\u043E\u0442\u0438\u043F \u041D\u0430\u0443\u0447\u043D\u043E\u0433\u043E \u041E\u0442\u043A\u0440\u044B\u0442\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, currentPhase.name, " \u2022 ", quantumState)), /* @__PURE__ */ React.createElement("div", { className: "relative w-96 h-96 cursor-pointer", onClick: handleDiscovery }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: `absolute top-1/2 left-1/2 w-20 h-20 rounded-full flex items-center justify-center transform -translate-x-1/2 -translate-y-1/2 transition-all duration-1000 ${discoveryMode ? "scale-150 animate-spin" : "scale-100"}`,
      style: {
        background: `radial-gradient(circle, ${currentPhase.color}, ${currentPhase.color}88, transparent)`,
        boxShadow: discoveryMode ? `0 0 80px ${currentPhase.color}` : `0 0 40px ${currentPhase.color}`,
        border: `2px solid ${currentPhase.color}`
      }
    },
    /* @__PURE__ */ React.createElement("span", { className: `text-3xl transition-all duration-500 ${discoveryMode ? "animate-bounce" : ""}` }, currentPhase.symbol)
  ), [120, 160, 200, 240].map((radius, ringIndex) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: radius,
      className: "absolute top-1/2 left-1/2 border border-white border-opacity-20 rounded-full",
      style: {
        width: `${radius}px`,
        height: `${radius}px`,
        transform: "translate(-50%, -50%)",
        animation: quantumState === "superposition" ? `spin ${10 + ringIndex * 2}s linear infinite reverse` : quantumState === "entangled" ? `spin ${8 + ringIndex}s ease-in-out infinite` : `spin ${15 + ringIndex * 3}s linear infinite`
      }
    },
    [0, 90, 180, 270].slice(0, ringIndex + 1).map((angle, elementIndex) => /* @__PURE__ */ React.createElement(
      "div",
      {
        key: angle,
        className: `absolute w-6 h-6 rounded-full flex items-center justify-center transition-all duration-1000 ${discoveryMode ? "animate-pulse scale-125" : ""}`,
        style: {
          top: "50%",
          left: "50%",
          transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(-${radius / 2}px) rotate(-${angle}deg)`,
          backgroundColor: phases[(ringIndex + elementIndex) % phases.length].color,
          boxShadow: `0 0 15px ${phases[(ringIndex + elementIndex) % phases.length].color}`,
          opacity: discoveryMode ? 1 : 0.8
        }
      },
      /* @__PURE__ */ React.createElement("span", { className: "text-xs" }, phases[(ringIndex + elementIndex) % phases.length].symbol)
    ))
  )), quantumState === "entangled" && /* @__PURE__ */ React.createElement("svg", { className: "absolute inset-0 w-full h-full pointer-events-none" }, [...Array(8)].map((_, i) => {
    const angle1 = i * 45 * Math.PI / 180;
    const angle2 = (i + 2) * 45 * Math.PI / 180;
    const x1 = 192 + Math.cos(angle1) * 80;
    const y1 = 192 + Math.sin(angle1) * 80;
    const x2 = 192 + Math.cos(angle2) * 120;
    const y2 = 192 + Math.sin(angle2) * 120;
    return /* @__PURE__ */ React.createElement(
      "line",
      {
        key: i,
        x1,
        y1,
        x2,
        y2,
        stroke: currentPhase.color,
        strokeWidth: "1",
        opacity: "0.6",
        className: "animate-pulse"
      }
    );
  })), discoveryMode && [...Array(3)].map((_, i) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: i,
      className: "absolute top-1/2 left-1/2 border-2 rounded-full pointer-events-none",
      style: {
        borderColor: currentPhase.color,
        animation: `discovery-wave 2s ease-out forwards`,
        animationDelay: `${i * 0.3}s`,
        transform: "translate(-50%, -50%)"
      }
    }
  ))), /* @__PURE__ */ React.createElement("div", { className: "mt-8 max-w-2xl text-center z-20" }, /* @__PURE__ */ React.createElement("div", { className: `bg-black bg-opacity-50 rounded-lg p-6 backdrop-blur-sm border transition-all duration-1000 ${discoveryMode ? "border-white scale-105" : "border-gray-600"}` }, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-bold text-white mb-4" }, "\u{1F52C} \u041D\u0430\u0443\u0447\u043D\u043E\u0435 \u041E\u0442\u043A\u0440\u044B\u0442\u0438\u0435"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-200 mb-4" }, discoveries[phase]), /* @__PURE__ */ React.createElement("div", { className: "flex justify-center space-x-4 text-sm" }, /* @__PURE__ */ React.createElement("span", { className: "text-cyan-300" }, "\u0421\u0438\u043C\u0431\u0438\u043E\u0437: \u0427\u0435\u043B\u043E\u0432\u0435\u043A + \u0418\u0418"), /* @__PURE__ */ React.createElement("span", { className: "text-purple-300" }, "\u041A\u0432\u0430\u043D\u0442\u043E\u0432\u044B\u0435 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438"), /* @__PURE__ */ React.createElement("span", { className: "text-green-300" }, "Child Safety First")))), /* @__PURE__ */ React.createElement("div", { className: "absolute top-4 left-4 space-y-2" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400" }, "\u041A\u0432\u0430\u043D\u0442\u043E\u0432\u043E\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435:"), /* @__PURE__ */ React.createElement("div", { className: "flex space-x-2" }, ["coherent", "superposition", "entangled"].map((state) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: state,
      onClick: () => setQuantumState(state),
      className: `px-2 py-1 rounded text-xs transition-all ${quantumState === state ? "bg-cyan-500 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"}`
    },
    state
  )))), /* @__PURE__ */ React.createElement("div", { className: "absolute top-4 right-4 space-y-2" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400" }, "\u0421\u043A\u043E\u0440\u043E\u0441\u0442\u044C \u043E\u0440\u0431\u0438\u0442:"), /* @__PURE__ */ React.createElement("div", { className: "flex space-x-2" }, [0.5, 1, 2].map((speed) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: speed,
      onClick: () => setOrbitSpeed(speed),
      className: `px-2 py-1 rounded text-xs transition-all ${orbitSpeed === speed ? "bg-purple-500 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"}`
    },
    speed,
    "x"
  )))), /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-4 left-4 flex space-x-2" }, phases.map((phaseItem, index) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: phaseItem.name,
      className: `w-3 h-3 rounded-full transition-all duration-500 ${index === phase ? "scale-125" : "scale-100 opacity-60"}`,
      style: {
        backgroundColor: phaseItem.color,
        boxShadow: index === phase ? `0 0 10px ${phaseItem.color}` : "none"
      }
    }
  ))), /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-4 right-4 text-xs text-gray-500 text-right" }, /* @__PURE__ */ React.createElement("div", null, "Terra Codex Dynamic Logo"), /* @__PURE__ */ React.createElement("div", null, "Living Symbol of Discovery"), /* @__PURE__ */ React.createElement("div", null, "Click to trigger discovery wave")), /* @__PURE__ */ React.createElement("style", { jsx: true }, `
        @keyframes spin {
          from { transform: translate(-50%, -50%) rotate(0deg); }
          to { transform: translate(-50%, -50%) rotate(360deg); }
        }
        
        @keyframes discovery-wave {
          0% {
            width: 40px;
            height: 40px;
            opacity: 1;
          }
          100% {
            width: 400px;
            height: 400px;
            opacity: 0;
          }
        }
      `));
};
var stdin_default = DynamicTerraCodex;
export {
  stdin_default as default
};
